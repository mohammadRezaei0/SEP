package com.example.mohammadrezaei.piece.MOdelsView

import android.os.Bundle
import android.support.design.widget.BottomSheetDialogFragment
import android.support.design.widget.TextInputEditText
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.mohammadrezaei.piece.Internets12.StaticForAll
import com.example.mohammadrezaei.piece.Model.TypeBottem
import com.example.mohammadrezaei.piece.R
import java.lang.Exception

class MyBottemSheet : BottomSheetDialogFragment {
    constructor() : super()

    //        lateinit var groupOprations:RadioGroup
    lateinit var myListeners: MyBottomListeners
    lateinit var setRadioGroup: HashSet<RadioButton>
    private var checkedId: Int = 0
    lateinit var stringRa: TextView
    private var typesB: TypeBottem = TypeBottem.EMPTY
    var fin = false

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        if (!fin)
            myListeners.getterValueAtters("", TypeBottem.EMPTY)
        super.onDestroy()
    }

    override fun dismiss() {
//        myListeners.getterValueAtters("")
//        if (!fin)
//            myListeners.getterValueAtters("")
        super.dismiss()
    }


    interface MyBottomListeners {
        fun getterValueAtters(selectedValues: String, types: TypeBottem): String
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.row_values, container, false)
        val groupOprations: RadioGroup = view.findViewById<RadioGroup>(R.id.groupOprations)
        setRadioGroup = HashSet()
//        val groupOprations:RadioGroup=RadioGroup(view.context)
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.equalsWith))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.equalsWith))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.bigerAndEquls))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.bigerFor))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.lowerAndEqual))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.lowerFor))
//        groupOprations.addView(view.findViewById<RadioButton>(R.id.notEqual))

        stringRa = view.findViewById<TextView>(R.id.stringRaidos)
        addSListeners(view.findViewById<RadioButton>(R.id.equalsWith))
        addSListeners(view.findViewById<RadioButton>(R.id.bigerAndEquls))
        addSListeners(view.findViewById<RadioButton>(R.id.bigerFor))
        addSListeners(view.findViewById<RadioButton>(R.id.lowerAndEqual))
        addSListeners(view.findViewById<RadioButton>(R.id.lowerFor))
        addSListeners(view.findViewById<RadioButton>(R.id.notEqual))
//        groupOprations.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
//
////            var stringRa:TextView=view.findViewById<TextView>(R.id.stringRaidos)
//            var radioButton=view.findViewById<RadioButton>(checkedId)
//            stringRa.text=radioButton.text
//        })
        view.findViewById<TextInputEditText>(R.id.valueAtter).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                try {
                    val sw=s.toString().trim()
                    if(sw.length>0){
                    val a = sw.toDoubleOrNull()
                    if (a == null) {
                        checkedRaido(R.id.equalsWith, true)
                        typesB = TypeBottem.TEXT
                        Log.d("is null : ", "null")
                    } else {
                        typesB = TypeBottem.NUMERIC
                        checkedRaido(-1, false)
                        Log.d("not null : ", a.toString())
                    }}else{
                        typesB=TypeBottem.EMPTY
                        Log.d(" empty : ", "empty")
                    }
//                        StaticForAll.toastMyMessage(context,)
                } catch (ex: Exception) {
                    Log.d("error :  ", ex.message)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }
        })
        val setValue = view.findViewById<Button>(R.id.setValueAtter)
        setValue.setOnClickListener(View.OnClickListener {
            var string = ""
            var radioButton = view.findViewById<RadioButton>(groupOprations.checkedRadioButtonId)

            val edit = view.findViewById<TextInputEditText>(R.id.valueAtter)
            //nulls
            string = "values" + edit.text.toString()
//            (setRadioGroup[tag] as RadioButton).text.toString()
            if (typesB == TypeBottem.TEXT) {
                string = "?" + "'" + edit.text.toString() + "'"
            } else if (typesB == TypeBottem.NUMERIC) {
                string = convertStringToOprater((view.findViewById<RadioButton>(checkedId)).text.toString()) + "'" + edit.text.toString() + "'"
            } else {
                string = ""
            }
            myListeners.getterValueAtters(string, typesB)
            fin = true
            dismiss()
        })
        return view
    }

    private fun checkedRaido(ids: Int, b: Boolean) {
        for (i in setRadioGroup.iterator()) {
            if (b) {
                i.isEnabled = false
                if (i.id == ids) {
                    i.isEnabled = true
                    i.isChecked = true
                } else
                    i.isChecked = false
            } else {
                i.isEnabled = true
            }
//                return i
        }
//        return null
    }

    fun addSListeners(ra: RadioButton) {
        ra.tag = setRadioGroup.size
        if (ra.tag == 0) {
            ra.isChecked = true
            checkedId = ra.id
        }
        setRadioGroup.add(ra)
        ra.setOnClickListener(View.OnClickListener {
            var itra = setRadioGroup.iterator()
            while (itra.hasNext()) {
                var rw = itra.next()
                if (rw.tag == it.tag) {
                    stringRa.text = rw.text
                    checkedId = rw.id
                    rw.isChecked = true
                } else {
                    rw.isChecked = false
                }
            }
        })
    }

    fun convertStringToOprater(op: String): String {
        when (op) {
            resources.getString(R.string.equal_with) -> {
                return "="
            }
            resources.getString(R.string.not_equal) -> {
                return "<>"
            }
            resources.getString(R.string.biger_equal) -> {
                return ">="
            }
            resources.getString(R.string.biger_for) -> {
                return ">="
            }
            resources.getString(R.string.lower_equal) -> {
                return "<="
            }
            resources.getString(R.string.lower_for) -> {
                return "<"
            }
            else -> {
                return "="
            }
        }
    }

//    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
//        super.onCreateContextMenu(menu, v, menuInfo)
//    }
}