package com.example.mohammadrezaei.piece

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Comment2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment2)
    }
}
