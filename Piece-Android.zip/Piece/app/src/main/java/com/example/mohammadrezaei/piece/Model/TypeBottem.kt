package com.example.mohammadrezaei.piece.Model

enum class TypeBottem {
    NUMERIC,TEXT,EMPTY
}