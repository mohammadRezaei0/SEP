package com.example.mohammadrezaei.piece

import android.animation.AnimatorInflater
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.text.Html
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_dasbord2.*
import java.util.*
import kotlin.math.max
import kotlin.math.min

class Dasbord2Activity : AppCompatActivity(), ViewPager.OnPageChangeListener {


    private lateinit var pager: ViewPager
    private lateinit var linearDot: LinearLayout
    private lateinit var layouts: Array<Int>
    //    private lateinit var buttonDot: Array<TextView>
    private lateinit var buttonDot: Array<ImageView>
    private lateinit var textComment: Array<String>
    private lateinit var textMain: Array<String>
    private lateinit var commentTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dasbord2)
        pager = pagerDots
        linearDot = linerDots
        commentPagerViews.setText(Html.fromHtml("&#8226"))
        layouts = Array(5) { 0 }
        for (x in 0..4) {
            layouts[x] = R.layout.row_pager
        }
//        buttonDot = Array(5) { TextView(this) }
        buttonDot = Array(5) { ImageView(this) }
        commentTextView = commentPagerViews
//        textComment = Array(5) { "" }
        textComment = arrayOf(
                getFromResourceString(R.string.nochechesComment)
                , getFromResourceString(R.string.chechesComment)
                , getFromResourceString(R.string.commentForAll)
                , getFromResourceString(R.string.whileLoading)
                , getFromResourceString(R.string.exits)
        )
        textMain = arrayOf(
                getFromResourceString(R.string.nocheches)
                , getFromResourceString(R.string.cheches)
                , getFromResourceString(R.string.commentForAl)
                , getFromResourceString(R.string.whileLoadi)
                , getFromResourceString(R.string.exit)
        )
//        var ds = "sa"
//        for (x in 0..4) {
//            ds += "a1" + x.toString()
//            textComment[x] = ds
//        }
        addButtonDot(0)
//        val m=Myaddapter()
        pager.adapter = Myaddapter()
        pager.addOnPageChangeListener(this)


        goBefor.setOnClickListener {
            pager.currentItem = max(pager.currentItem - 1, 0)
//                goBefor.isEnabled=(pager.currentItem!=0)
        }
        goNext.setOnClickListener {
            pager.currentItem = min(pager.currentItem + 1, buttonDot.size - 1)
//            pager.isEnabled=(pager.currentItem!=buttonDot.size-1)
        }
        addBackgroundAnimation()
    }

    private fun addBackgroundAnimation() {
        var test = true
        var counter = 0
        val displayMetrics = DisplayMetrics()
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        var hiegh = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels
//        var a = arrayOf(R.drawable.ic_exposure_zero_white_24dp, R.drawable.ic_looks_one_white_24dp)
        var a = arrayOf(R.drawable.ic_0, R.drawable.ic_11)
//        var a = arrayOf(R.drawable.ic_000, R.drawable.ic_111)
        var listAnimation = ArrayList<ObjectAnimator>()
        while (test) {
            var b = true
//            var wConter=0
            var tCounters = 0
            val duration:Long=10000
            var startDelay = Random().nextInt(10000).toLong()
            while (b) {
                val i = ImageView(this)
                val params1 = RelativeLayout.LayoutParams(50, 50)
//            params1.leftMargin = wConter
                params1.leftMargin = -50
                params1.topMargin = counter
                var po = ((Random().nextInt()) % 2)
                if (po < 0)
                    po *= -1
                i.setImageDrawable(resources.getDrawable(a[po]))
                animationRalativeLayout.addView(i, params1)
                val trans: ObjectAnimator =
                        ObjectAnimator.ofFloat(i, "translationX", 0f, (width+50).toFloat())
                trans.repeatCount = ObjectAnimator.INFINITE
                trans.startDelay = startDelay
                trans.startDelay = startDelay + tCounters
                trans.duration = duration
                listAnimation.add(trans)
//                wConter-=75
//                b=(wConter*-1)<width
                tCounters += 500
               b= tCounters<duration
            }
//            trans.start()
            counter += 75
            test = counter < hiegh
        }
        listAnimation.forEach {
            it.start()
        }
//       var h= Handler()
//        var r=object :Runnable{
//            override fun run() {
//                listAnimation.forEach {
//                    it.startDelay= Random().nextInt(10000).toLong()
//                }
//                h.post(this)
//            }
//
//        }
//        h.post(r)
//        Runnable {
//            listAnimation.forEach {
//                it.startDelay= Random().nextInt(10000).toLong()
//            }
//            h.post(it)
//        }
//        h.post(r)
    }

    private fun getFromResourceString(id: Int): String = resources.getString(id)

    private fun addButtonDot(position: Int) {

        for (x in 0..buttonDot.size - 1) {
//            Toast.makeText(this,(x.toString()+""),Toast.LENGTH_LONG).show()
//            buttonDot[x] = TextView(this)
//            buttonDot[x].textSize=30f
//            buttonDot[x].gravity=Gravity.BOTTOM
//            buttonDot[x].setText(Html.fromHtml("&#8226;"))
            buttonDot[x] = ImageView(this)
            buttonDot[x].setImageDrawable(resources.getDrawable(R.drawable.ic_radio_button_unchecked_black_24dp))
            buttonDot[x].scaleType = ImageView.ScaleType.FIT_XY
            buttonDot[x].setOnClickListener {
                pager.currentItem = x
            }
//            buttonDot[x].setTextSize(35f)
//            buttonDot[x].setTextColor(inac)
            linearDot.addView(buttonDot[x])
        }

        changeColorActive(position)
    }

    fun changeColorActive(position: Int): Unit {

        var ac = resources.getColor(R.color.crime)
        var inac = resources.getColor(R.color.green_12)
        for (x in 0..buttonDot.size - 1) {
//            Toast.makeText(this,(x.toString()+""),Toast.LENGTH_LONG).show()
//            buttonDot[x]= TextView(this)
//            buttonDot[x].setText(Html.fromHtml("&#8226;"))
//            buttonDot[x].setTextSize(45f)
            if (x == position) {
                buttonDot[x].setImageDrawable(resources.getDrawable(R.drawable.ic_radio_button_checked_black_24dp))
//                buttonDot[x].setTextColor(ac)
                commentTextView.setText(textComment[x])
            } else
                buttonDot[x].setImageDrawable(resources.getDrawable(R.drawable.ic_radio_button_unchecked_black_24dp))
//            linearDot.addView(buttonDot[x])
        }
    }


    override fun onPageScrollStateChanged(p0: Int) {

    }

    override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {

    }

    override fun onPageSelected(p0: Int) {
        changeColorActive(p0)
    }


    inner class Myaddapter : PagerAdapter {
        private lateinit var layoutInflater: LayoutInflater
        private var images = listOf<Int>(
                R.drawable.ic_shopping_basket_white_24dp
                , R.drawable.ic_playlist_add_check_withe_24dp
                , R.drawable.ic_comment_white_24dp
                , R.drawable.ic_all_inclusive_white_24dp
                , R.drawable.ic_exit_to_app_white_24dp
                , R.drawable.ic_storage_white_24dp
                , R.drawable.ic_color_lens_white_24dp
                , R.drawable.ic_fiber_new_white_24dp)

        constructor() {
            layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        private fun imageOfDrawable(i: Int): Drawable {
            return resources.getDrawable(images[i])
        }

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            var view = layoutInflater.inflate(layouts[position], container, false)
            view.findViewById<ImageView>(R.id.imagePagerDashbord).setImageDrawable(imageOfDrawable(position))
            view.findViewById<TextView>(R.id.textPagerDashbord1).text = textMain[position]
            view.setOnClickListener {
                when (pager.currentItem) {
                    0 -> {
                        startActivity(Intent(this@Dasbord2Activity, Piece2Activity::class.java))
                    }
                    1 -> {
                        startActivity(Intent(this@Dasbord2Activity, PieceMatch2Activity::class.java))
                    }
                    2 -> {
                        startActivity(Intent(this@Dasbord2Activity, Comment2Activity::class.java))
                    }
                    3 -> {
//                        startActivity(Intent(this@Dasbord2Activity,Piece2Activity::class.java))
                    }
                    4 -> {
                        finish()
                        System.exit(0)
                    }
                    else -> {
                    }
//                    in 0..2 ->{
//                        startActivity(Intent(this@Dasbord2Activity,PieceMatch2Activity::class.java))
//                    }
//                    in 3..10 -> {
//                        startActivity(Intent(this@Dasbord2Activity,Piece2Activity::class.java))
//                    }
//                    else -> {
//                        startActivity(Intent(this@Dasbord2Activity,Login2Activity::class.java))
//                    }

                }
            }
            container.addView(view)
            return view
        }

        override fun isViewFromObject(p0: View, p1: Any): Boolean {
            return p0 == p1
        }

        override fun getCount(): Int {
            return layouts.size
        }

        override fun destroyItem(container: ViewGroup, position: Int, vi: Any) {
            var view = vi as View
            container.removeView(view)
        }


    }
}
