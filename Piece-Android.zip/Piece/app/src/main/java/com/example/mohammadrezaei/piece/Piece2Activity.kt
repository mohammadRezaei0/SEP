package com.example.mohammadrezaei.piece

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.CardView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.NetworkImageView
import com.example.mohammadrezaei.piece.Internets12.MySingleton
import com.example.mohammadrezaei.piece.Internets12.StaticForAll
import com.example.mohammadrezaei.piece.Model.KeyObjects
import com.example.mohammadrezaei.piece.Model.ListPeice
import com.example.mohammadrezaei.piece.Model.PieceModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_piece2.*
import org.json.JSONObject

class Piece2Activity : AppCompatActivity() {
    private lateinit var recPeice: RecyclerView
    private lateinit var adapterPeice: MyReceycleAdapterPeice
    //    private lateinit var mapIDPiece:HashMap<Int,PieceModel>
    private lateinit var allMainPiece: ArrayList<PieceModel>

    private var selectPieceString: String = """
        SELECT Distinct("Piece"."idPiece"), "Piece"."idBrunch", "namePiece", price, "imageSrcs"
            ,(select (select array_to_json(array_agg(row_to_json(t)))
                from (
                  select "keyAttribute", "valueAttribute" from public."Attribute" where "Piece"."idPiece"="Attribute"."idPiece"
                  and "keyAttribute"<>'need'
                ) t)::jsonb as s)
            FROM public."Piece","Attribute" where "Piece"."idPiece"="Attribute"."idPiece"
    """.trimIndent()
    //            "SELECT Distinct(\"Piece\".\"idPiece\"), \"Piece\".\"idBrunch\", \"namePiece\", price, \"imageSrcs\"\n" +
//            "\t,(select (select array_to_json(array_agg(row_to_json(t)))\n" +
//            "    from (\n" +
//            "      select \"keyAttribute\", \"valueAttribute\" from public.\"Attribute\" where \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\"\n" +
//            "    ) t)::text as s)\n" +
//            "\tFROM public.\"Piece\",\"Attribute\" where \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\" \n"
    private var selectWhereString: String = ""
//            "\tand ((\"keyAttribute\"='WEIDTH' and \"valueAttribute\">='100')) and \"idBrunch\"=1 ;"

//    private val sOOOO="SELECT Distinct(\"Piece\".\"idPiece\"), \"Piece\".\"idBrunch\", \"namePiece\", price, \"imageSrcs\"\n" +
//            "\t,(select (select array_to_json(array_agg(row_to_json(t)))\n" +
//            "    from (\n" +
//            "      select \"keyAttribute\", \"valueAttribute\" from public.\"Attribute\" where \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\"\n" +
//            "    ) t)::text as s)\n" +
//            "\tFROM public.\"Piece\",\"Attribute\" where \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\" \n" +
//            "\tand ((\"keyAttribute\"='WEIDTH' and \"valueAttribute\">='100')) and \"idBrunch\"=1 ;"

    private lateinit var jsonReqest: JsonObjectRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_piece2)
        recPeice = recyclerPiece
        allMainPiece = ArrayList<PieceModel>()
        adapterPeice = MyReceycleAdapterPeice(ListPeice(ArrayList<PieceModel>()))
//        mapIDPiece= HashMap()
//        selectWhereString=""
        selectWhereString = try {
            intent.getStringExtra(KeyObjects.pieceSelectKey)
//            Toast.makeText(this,selectWhereString,Toast.LENGTH_LONG).show()
        } catch (ex: Exception) {
            ""
//            Toast.makeText(this,"sfa",Toast.LENGTH_LONG).show()
        }
        requestServer()

        querysetSearch()
        enterBasket.setOnClickListener {
            val intent: Intent = Intent(this, BasketShop2Activity::class.java)
            val f = allMainPiece.filter { it.ischoose }
//            val a=ArrayList<PieceModel>(mapIDPiece.values)
            val a = ArrayList<PieceModel>(f)
            intent.putExtra(KeyObjects.choosenItem, Gson().toJson(ListPeice(a)))
//            StaticForAll.toastMyMessage(this, Gson().toJson(ListPeice(a)))
            startActivity(intent)
        }
        filterEnters.setOnClickListener {
            var intent: Intent = Intent(this, Filter2Activity::class.java)
            startActivityForResult(intent, KeyObjects.keyResult)
        }
    }

    private fun querysetSearch() {
        sershforPiece.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                var fiilter = allMainPiece.filter { it.namePiece.toLowerCase().contains(newText!!.toLowerCase()) }
//            allMainPiece.filter { model ->
//                model.namePiece.contentEquals(newText!!)
//            }
                adapterPeice.changeListModel(fiilter as ArrayList<PieceModel>)
                return true
            }
        })
    }

    private fun requestServer() {
        val params1: HashMap<String, String> = HashMap()
        params1.put("email", "wwww.ffff")
        params1.put("password", "erqwrw")
        params1.put("we", "re")
        params1.put("type", "select")
        params1.put("select", (selectPieceString + selectWhereString))
        val jo: JSONObject = JSONObject(params1)
        jsonReqest = JsonObjectRequest(Request.Method.POST,
                StaticForAll.URL, jo, Response.Listener { response ->
//            Toast.makeText(this, response.toString(), Toast.LENGTH_LONG).show()
            var listPeice = Gson().fromJson<ListPeice>(response.toString(), ListPeice::class.java)
            val linearLayoutManager = LinearLayoutManager(this)
            allMainPiece.clear()
            allMainPiece.addAll(listPeice.listPiece)
            adapterPeice = MyReceycleAdapterPeice(listPeice)
            recPeice.layoutManager = linearLayoutManager
            recPeice.adapter = adapterPeice
            recPeice.visibility = View.VISIBLE
            linearProgressLoading.visibility = View.INVISIBLE
//            Toast.makeText(this, "1-خطا در برقراری ارتباطaaaaaaaa", Toast.LENGTH_LONG).show()

        }, Response.ErrorListener {
            progressBarTexts.text = "تلاش مجدد"
            progressBarLoadings.visibility = View.INVISIBLE
            progressBarTexts.setOnClickListener {
                (it as TextView).text = resources.getString(R.string.whileLoading)
                progressBarLoadings.visibility = View.VISIBLE
                MySingleton.getInstance(this).requestQueue.add(jsonReqest)
            }
            Toast.makeText(this, "1-خطا در برقراری ارتباط", Toast.LENGTH_LONG).show()
        })

        MySingleton.getInstance(this).requestQueue.add(jsonReqest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == KeyObjects.keyResult) {
            if (resultCode == Activity.RESULT_OK) {
                selectWhereString = try {
                    data!!.getStringExtra(KeyObjects.pieceSelectKey)
                } catch (ex: Exception) {
                    Toast.makeText(this, "sfa", Toast.LENGTH_LONG).show()
                    ""
                }
//                Toast.makeText(this, selectPieceString + selectWhereString, Toast.LENGTH_LONG).show()
                Log.d("select", selectPieceString + selectWhereString)
                requestServer()
            } else {

            }
        } else {
        }
    }


    inner class MyHoldeler//            attributesPiece = itemView.findViewById(R.id.attrPieceList) as ListView
    (itemView: View) : RecyclerView.ViewHolder(itemView) {
        var layotCard: CardView
        var imagePiece: NetworkImageView
        var chooOrDele: TextView
        var periceText: TextView
        var nameText: TextView
        //      var attributesPiece: ListView
        var isDelete: Boolean


        init {
            imagePiece = itemView.findViewById(R.id.imagePice)
            chooOrDele = itemView.findViewById(R.id.chooseOrDelete)
            periceText = itemView.findViewById(R.id.pricePiece1)
            nameText = itemView.findViewById(R.id.namePeice1)
            layotCard = itemView.findViewById(R.id.cardPeice)
            imagePiece.setDefaultImageResId(R.drawable.l1)
            isDelete = false
        }

        fun loadImages(src:String?){
            try {
//                StaticForAll.toastMyMessage(this@Piece2Activity,src.toString())
//               var src1="https://upload.wikimedia.org/wikipedia/commons/2/20/Avant-Tower-Gaming-PC.png"
               var imageLoader= MySingleton(this@Piece2Activity).imageLoader
//                imageLoader.ImageContainer
                imagePiece.setImageUrl(src,imageLoader)
//                imageLoader.get(src?,object :ImageLoader.ImageListener{
//                    override fun onResponse(response: ImageLoader.ImageContainer?, isImmediate: Boolean) {
//                        imagePiece.setImageBitmap(response!!.bitmap)
//                    }
//
//                    override fun onErrorResponse(error: VolleyError?) {
//
//                    }
//                })
            }catch (ex:Exception){
                StaticForAll.toastMyMessage(this@Piece2Activity,ex.toString())
            }


        }
        fun chooceMode() {

            isDelete = false
            chooOrDele.setBackgroundColor(resources.getColor(R.color.green_12))
            chooOrDele.text = "انتخاب"
            chooOrDele.setTextColor(resources.getColor(R.color.withe_1))
        }

        fun deleteMode() {
            isDelete = true
            chooOrDele.setBackgroundColor(resources.getColor(R.color.red_1))
            chooOrDele.text = "حذف"
            chooOrDele.setTextColor(resources.getColor(R.color.withe_1))
        }

//      fun setAddap(stringModel:ArrayList<String>){
//          attributesPiece.adapter=MyAtterPeiece(stringModel)
//      }


        inner private class MyAtterPeiece : BaseAdapter {
            private var stringModelList1: ArrayList<String>

            constructor(stringModelList1: ArrayList<String>) {
                this.stringModelList1 = stringModelList1
//                Toast.makeText(this@Piece2Activity, stringModelList1.size.toString(), Toast.LENGTH_LONG).show()
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//              var v:View
                if (convertView == null) {
                    val t = TextView(this@Piece2Activity)
                    t.gravity = Gravity.CENTER
                    t.text = stringModelList1[position]
                    return t
                } else {
                    return convertView
                }
            }

            override fun getItem(position: Int): Any {
                return ""
            }

            override fun getItemId(position: Int): Long {
                return 0
            }

            override fun getCount(): Int {
                return stringModelList1.size
            }
        }


    }

    inner private class MyReceycleAdapterPeice(listPeice: ListPeice) : RecyclerView.Adapter<MyHoldeler>() {
        private lateinit var inflater: LayoutInflater
        private var listModel: ListPeice = listPeice

        init {
            inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        override fun onCreateViewHolder(group: ViewGroup, p1: Int): MyHoldeler {
            val view = inflater.inflate(R.layout.row_peice, group, false)
            val myHoldeler = MyHoldeler(view)
            addListeners(view, myHoldeler, p1)
            return myHoldeler
        }

        private fun addListeners(view: View, myHoldeler: MyHoldeler, p1: Int) {
            view.setBackgroundColor(resources.getColor(R.color.green_12))
            view.setOnClickListener {
                var position=recyclerPiece.getChildLayoutPosition(it)
                forChangeModes(listModel.listPiece[position], myHoldeler, true)
//                    if(myHoldeler.isDelete){
//                        mapIDPiece.remove(listModel.listPiece[p1].idPiece)
//                        myHoldeler.layotCard.setBackgroundColor(resources.getColor(R.color.green_12))
//                        myHoldeler.chooceMode()
//                    }else{
//                        mapIDPiece.put(listModel.listPiece[p1].idPiece,listModel.listPiece[p1])
//                        myHoldeler.layotCard.setBackgroundColor(resources.getColor(R.color.red_1))
//                        myHoldeler.deleteMode()
//                    }
            }
        }


        override fun getItemCount(): Int = listModel.listPiece.size


        override fun onBindViewHolder(p0: MyHoldeler, p1: Int) {
            val p: PieceModel = listModel.listPiece[p1]
            p0.nameText.text = p.namePiece
            p0.loadImages(p.imageSrcs)
            p0.periceText.text = p.price.toString()
            forChangeModes(p, p0, false)
//            if(p0.isDelete){
//                mapIDPiece.remove(p.idPiece)
//                p0.layotCard.setBackgroundColor(resources.getColor(R.color.green_12))
//                p0.chooceMode()
//            }else{
//                mapIDPiece.put(p.idPiece,p)
//                p0.layotCard.setBackgroundColor(resources.getColor(R.color.red_1))
//                p0.deleteMode()
//            }
            p0.chooOrDele.setOnClickListener {
                forChangeModes(p, p0, true)
//                if(p0.isDelete){
//                    mapIDPiece.remove(p.idPiece)
//                    p0.layotCard.setBackgroundColor(resources.getColor(R.color.green_12))
//                    p0.chooceMode()
//                }else{
//                    mapIDPiece.put(p.idPiece,p)
//                    p0.layotCard.setBackgroundColor(resources.getColor(R.color.red_1))
//                    p0.deleteMode()
//                }
            }
        }

        private fun forChangeModes(p: PieceModel, h: MyHoldeler, b: Boolean) {
//            if(!b)
//
//            if(!b){
//               var r= mapIDPiece.get(p.idPiece)
//                if(mapIDPiece.get(p.idPiece)!=null){
//                }
//            }
//            else

            if (b)
                if (p.ischoose) {
                    p.ischoose=false
//                    if (b)
//                        mapIDPiece.remove(p.idPiece)
                    h.layotCard.setBackgroundColor(resources.getColor(R.color.green_12))
                    h.chooceMode()
                } else {
                    p.ischoose=true
//                    if (b)
//                        mapIDPiece.put(p.idPiece, p)
                    h.layotCard.setBackgroundColor(resources.getColor(R.color.red_1))
                    h.deleteMode()
                }
            if (p.ischoose) {
                h.layotCard.setBackgroundColor(resources.getColor(R.color.green_12))
            } else {
                h.layotCard.setBackgroundColor(resources.getColor(R.color.red_1))
            }
            val e=allMainPiece.filter { it.ischoose }
//            for (y in e)
//                StaticForAll.toastMyMessage(this@Piece2Activity,y.namePiece)
        }

        fun changeListModel(list: ArrayList<PieceModel>) {
//            listModel.listPiece.clear()
            var l = ListPeice(list)
            listModel = l
            notifyDataSetChanged()
        }
    }
}
