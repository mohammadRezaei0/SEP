package com.example.mohammadrezaei.piece

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_filter2.*
import android.widget.RadioButton
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.example.mohammadrezaei.piece.Internets12.MySingleton
import com.example.mohammadrezaei.piece.Internets12.StaticForAll
import com.example.mohammadrezaei.piece.MOdelsView.MyBottemSheet
import com.example.mohammadrezaei.piece.Model.*
import com.google.gson.Gson


class Filter2Activity : AppCompatActivity() {
    private lateinit var groupList: GridView
    private lateinit var attrList: GridView
    private lateinit var atterAdapter: MyAdapterFilter
    private var currKeys: String = ""
    private lateinit var loadingLinearLayout: LinearLayout
    private var selectForGroups: String = """
        SELECT "IdBrunch", "nameBrunch"
            FROM public."Brunch";
    """.trimIndent()

//            "SELECT \"IdBrunch\", \"nameBrunch\"\n" +
//            "\tFROM public.\"Brunch\";"
    private var selectForAtter: String = "SELECT DISTINCT ON(\"keyAttribute\") \"keyAttribute\", \"valueAttribute\",\"idAttribute\"\n" +
            ",\"groupAttribute\", \"typeAttribute\"\n" +
            "                  FROM public.\"Attribute\",\"Piece\" where \"Attribute\".\"idPiece\"=\"Piece\".\"idPiece\" and \"idBrunch\"=1 ;"
//    private var perResultMap: HashMap<Int, String>? = null

    private var idBrunchSelect:Int=-1
//    private var attrMap:HashMap<Int,AtterModel1>
    private var array12:ArrayList<AtterModel1>

    init {
//        attrMap=HashMap()
        array12= ArrayList()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter2)
//        perResultMap = HashMap()
        loadingLinearLayout = linearLoadingFilterPage
        groupList = groupPeiceFilter
        attrList = attrPieceFilter
        var request = JsonObjectRequest(Request.Method.POST, StaticForAll.URL, StaticForAll.getPostModel(selectForGroups), Response.Listener { response ->
//            StaticForAll.toastMyMessage(this, "res" + response.toString())
            groupList.visibility=View.VISIBLE
            attrList.visibility=View.VISIBLE
            loadingLinearLayout.visibility=View.GONE
            val a = ArrayList<Any>()
            val l = BrunchModel(-1, "همه", true)
            a.add(l)
            val g = Gson().fromJson<ListBrunch>(response.toString(), ListBrunch::class.java)
            a.addAll(g.listBrunch)
            groupList.adapter = MyAdapterFilter(1, a)
            val a2 = ArrayList<Any>()
            a2.add(resources.getString(R.string.noAtterExists))
            atterAdapter = MyAdapterFilter(2, a2)
            attrList.adapter = atterAdapter
        }, Response.ErrorListener {
            StaticForAll.toastError(this)
        })

        MySingleton.getInstance(this).requestQueue.add(request)

        addListenerS()

    }

    private fun addListenerS() {
        okImageViews.setOnClickListener {
            if(idBrunchSelect>=0){

//                var a="""
//                    select "valueAttribute"->'valueAttribute'>='100.000' from "Attribute"
//                """.trimIndent()
                var tea="""
                    Exists(select * from "Attribute" where  "Piece"."idPiece"="Attribute"."idPiece"
					and "keyAttribute"='Ju' and "valueAttribute"->'valueAttribute'?'ass'
				   )
                """.trimIndent()
//                val a=((attrList.adapter as MyAdapterFilter).model.filter {
//                     (it as AtterModel1).showKeyValues.equals("")
//
//                }as List<*>)
//                StaticForAll.toastMyMessage(this,"this is map size :"+attrMap.size)
                var s=array12.filter {
                    it.cheacked
                }
                var selectWhereString:String="and ("
//                for (e in s){
////                    val e= attrMap.get(i)
//                    selectWhereString+="(\"keyAttribute\"='"+e!!.keyAttribute
//                    selectWhereString+="' and \"valueAttribute\"->'valueAttribute'"+e.showKeyValues
//                    selectWhereString+=") and"
//                }
                for (e in s){
//                    val e= attrMap.get(i)
                    selectWhereString+="(" +"Exists(select * from \"Attribute\" where  \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\"\n" +
                            "\tand "
                    selectWhereString+="\"keyAttribute\"='"+e!!.keyAttribute
                    selectWhereString+="' and \"valueAttribute\"->'valueAttribute'"+e.showKeyValues
                    selectWhereString+=")) and"
                }
//                for (i in attrMap.keys){
////                    for (i in a){
////                        val e= i
//                        val e= attrMap.get(i)
//                    selectWhereString+="(\"keyAttribute\"='"+e!!.keyAttribute
//                    selectWhereString+="' and \"valueAttribute\"->'valueAttribute'"+e.showKeyValues
//                    selectWhereString+=") and"
//                }
                selectWhereString+=" \"idBrunch\"="+idBrunchSelect+")"
//                StaticForAll.toastMyMessage(this,selectWhereString)
                var intent=Intent()
                intent.putExtra(KeyObjects.pieceSelectKey,selectWhereString)
                setResult(Activity.RESULT_OK,intent)
                finish()
//                selectWhereString:String=
//                        "\tand ((\"keyAttribute\"='WEIDTH' and \"valueAttribute\">='100')) and \"idBrunch\"=1 ;"
            }else{
                finish()
                StaticForAll.toastMyMessage(this,"mybad")
            }
        }
    }


    inner class MyAdapterFilter(var type: Int, var model: ArrayList<Any>) : BaseAdapter(), MyBottemSheet.MyBottomListeners {
        //       lateinit var group:ArrayList<RadioButton>
        var ra: RadioGroup? = null
        var setGroup: HashSet<RadioButton>? = null
        var pos: Int = -1

        init {
            if (type == 1) {
                setGroup = HashSet()
            }
            if (type == 2) {
                attrList.numColumns=1
            } else{
                attrList.numColumns=2
            }
        }

        override fun getterValueAtters(selectedValues: String, types: TypeBottem): String {
//            Toast.makeText(this@Filter2Activity, selectedValues, Toast.LENGTH_LONG).show()
//            if(!selectedValues.equals(""))
//            if(types==TypeBottem.NUMERIC){
//            changeStringModel(selectedValues, !selectedValues.equals(""))}
//            else if(types==TypeBottem.TEXT){
                changeStringModel(selectedValues, !selectedValues.equals(""))
//            }else{
//
//            }
            return ""
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//            var linearLayout:LinearLayout= LinearLayout(this@Filter2Activity)
            var view: View
            if (convertView == null) {
                if (type == 1) {
                    val ra = RadioButton(this@Filter2Activity)
                    ra.tag = position
                    ra.id = position
                    setGroup!!.add(ra)
                    ra.setOnClickListener(View.OnClickListener {
                        if (it.id == 0) {
                            attrList.isEnabled = false
                            val array: ArrayList<Any>
                            array = ArrayList()
                            array.add(resources.getString(R.string.noAtterExists))
                            attrList.adapter = MyAdapterFilter(2, array)
                        } else {
                            var sa = (it as RadioButton).id
                            requestServerData(sa)
//                        val ad=ArrayList<FilterModelList1>()
//                        ad.add(FilterModelList1("sss",false))
//                        ad.add(FilterModelList1("ssdwq",false))
//                        attrList.adapter = MyAdapterFilter(0,ad)
//                        attrList.isEnabled = true
                        }
                        val iterator = setGroup!!.iterator()
                        while (iterator.hasNext()) {
                            val rw = iterator.next()
                            if (rw.id == ra.id || rw === it) {
                                rw.setChecked(true)
                                idBrunchSelect=(model[rw.id] as BrunchModel).IdBrunch
                            } else {
                                rw.setChecked(false)
                            }
                        }
                    })
                    var b = model[position] as BrunchModel
                    ra.text = b.nameBrunch
                    ra.isChecked = b.cheacked
                    ra.id = position

                    if (position == 0) {
                        attrList.isEnabled = false
                    } else {
                        attrList.isEnabled = true
                    }
                    return ra
                } else if (type == 2) {
                    var ra = TextView(this@Filter2Activity)
//                attrList.numColumns=1
                    var s = model[position] as String
                    ra.text = s
                    return ra
                } else {
//                attrList.numColumns=2
                    val ra = CheckBox(this@Filter2Activity)

                    ra.setOnClickListener {
                        if (ra.isChecked) {
                            val ma = MyBottemSheet()
                            ma.show(supportFragmentManager, "value setters")
//                            pos = position
                            pos=it.id
//                        ma.myListeners=this
                            ma.myListeners = this
                        } else {
//                            var az = model[position] as AtterModel1
                            var az = model[it.id] as AtterModel1
//                            var t = az.showKeyValues
//                        var t=(model[position]as AtterModel1).showKeyValues
//                            if (az.showKeyValues == null || az.showKeyValues.equals("")) {
//                                t = az.keyAttribute
//                            } else {
//                                t = az.showKeyValues
//                            }
//                        t=t.substring(0,t.indexOf(":"))
//                            val aw=attrMap.remove(az.idAttributes)
//                            StaticForAll.toastMyMessage(this@Filter2Activity,"remove this is map size :"+attrMap.size)
//                            for (i in attrMap.keys){
//                                Log.d("rrrrrrrrrrr",attrMap.get(i).toString())
//                            }
//                            Log.d("asss",aw?.keyAttribute)
                            val f = AtterModel1(az.idAttributes,az.typeAttribute, az.groupAttribute, az.keyAttribute
//                                    , az.valueAttribute
                                    , "", false)
//                        var f=FilterModelList1(t,false)
                            model.set(it.id, f)
                            array12.clear()
                            array12.addAll(model as ArrayList<AtterModel1>)
                            attrList.adapter = MyAdapterFilter(0, model)
                        }


                    }
                    var az = model[position] as AtterModel1


                    if (az.showKeyValues == null || az.showKeyValues.equals("")) {
                        ra.text = az.keyAttribute
                    } else {
//                    if(az.showKeyValues==null ||az.showKeyValues.equals("")){
//                        az.showKeyValues=""
//                    StaticForAll.toastMyMessage(this@Filter2Activity,"empty or null")}
                        ra.text = az.keyAttribute+az.showKeyValues ?: ""
                    }
                    ra.isChecked = az.cheacked
                    ra.id=position
                    return ra
                }
            } else {
                view = convertView
                return view
            }

        }

        private fun requestServerData(sa: Int) {
            attrList.visibility = View.GONE
            loadingLinearLayout.visibility = View.VISIBLE
            var brunchModel = model[sa] as BrunchModel
//            val  params1:HashMap<String, String> =HashMap()
            val sa ="""
                SELECT DISTINCT ON("keyAttribute") "keyAttribute","idAttribute"
                    "groupAttribute", "typeAttribute"
                        FROM public."Attribute","Piece" where "Attribute"."idPiece"="Piece"."idPiece" and "idBrunch"=${brunchModel.IdBrunch}
            """.trimIndent()


//                    "SELECT DISTINCT ON(\"keyAttribute\") \"keyAttribute\", \"valueAttribute\",\"idAttribute\"\n" +
//                    ",\"groupAttribute\", \"typeAttribute\"\n" +
//                    "                  FROM public.\"Attribute\",\"Piece\" where \"Attribute\".\"idPiece\"=\"Piece\".\"idPiece\" and \"idBrunch\"="+ brunchModel.IdBrunch

//                    "SELECT DISTINCT ON(\"keyAttribute\") \"keyAttribute\", \"valueAttribute\",\"groupAttribute\", \"typeAttribute\"\n" +
//                    "\tFROM public.\"Attribute\",\"Piece\" where \"Attribute\".\"idPiece\"=\"Piece\".\"idPiece\" and \"idBrunchSelect\"=" + brunchModel.IdBrunch
//            params1.put("email", "wwww.ffff")
//            params1.put("password", "erqwrw")
//            params1.put("we", "re")
//            params1.put("type", "select")
//            params1.put("select", sa)
//            val jo: JSONObject = JSONObject(params1)
            var reqest = JsonObjectRequest(Request.Method.POST,
                    StaticForAll.URL, StaticForAll.getPostModel(sa), Response.Listener { response ->

                val ad = ArrayList<Any>()
                var listAtter1 = Gson().fromJson<ListAtter1>(response.toString(), ListAtter1::class.java)
                ad.addAll(listAtter1.listAtter1)
//                ad.add(FilterModelList1("sss",false))
//                ad.add(FilterModelList1("ssdwq",false))
                array12.clear()
                array12.addAll(ad as ArrayList<AtterModel1>)
                attrList.adapter = MyAdapterFilter(0, ad)
                attrList.isEnabled = true
                attrList.visibility = View.VISIBLE
                loadingLinearLayout.visibility = View.GONE
            }, Response.ErrorListener {
                Toast.makeText(this@Filter2Activity, "1-خطا در برقراری ارتباط", Toast.LENGTH_LONG).show()
            })
            MySingleton.getInstance(this@Filter2Activity).requestQueue.add(reqest)
        }

        fun changeStringModel(string: String, boolean: Boolean) {
            val atte = model[pos] as AtterModel1
            if (boolean) {
//          var f=AtterModel1((model[pos].text+": "+string),true)
//                var f1 = AtterModel1(atte.idAttributes,atte.typeAttribute, atte.groupAttribute, atte.keyAttribute, atte.valueAttribute,
//                        (atte.showKeyValues + ": " + string), true)
                val f1 = AtterModel1(atte.idAttributes,atte.typeAttribute, atte.groupAttribute, atte.keyAttribute,
//                        atte.valueAttribute,
                        string, true)
//                attrMap.put(f1.idAttributes,f1)
//                StaticForAll.toastMyMessage(this@Filter2Activity,"this is map size :"+attrMap.size)
//                for (i in attrMap.keys){
//                    Log.d("rrrrrrrrrrr",attrMap.get(i).toString())
//                }
                model.set(pos, f1)
            }
            array12.clear()
            array12.addAll(model as ArrayList<AtterModel1>)
            attrList.adapter = MyAdapterFilter(0, model)
        }


        override fun getItem(position: Int): Any {
            return ""
        }

        override fun getItemId(position: Int): Long {
            return 0
        }

        override fun getCount(): Int {
            return model.size
        }
    }
}
