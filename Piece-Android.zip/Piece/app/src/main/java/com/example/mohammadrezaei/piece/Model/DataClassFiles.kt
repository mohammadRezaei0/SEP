package com.example.mohammadrezaei.piece.Model

import com.google.gson.annotations.SerializedName


data class Coustomer(var userName: String, var phoneNumber: String, var password: String)

data class FilterModelList1(var text: String, var state: Boolean)

data class ListPeice(
        @SerializedName("data") var listPiece: ArrayList<PieceModel>
){
}
data class ListAtter1(
        @SerializedName("data") var listAtter1: ArrayList<AtterModel1>
)
data class ListBrunch(
        @SerializedName("data") var listBrunch: ArrayList<BrunchModel>
)

data class PieceModel(
        @SerializedName("idPiece") val idPiece: Int,
        @SerializedName("idBrunch") val idBrunch: Int,
        @SerializedName("namePiece") val namePiece: String,
        @SerializedName("price") val price: Long,
        @SerializedName("imageSrcs") val imageSrcs: String,
        @SerializedName("s") val listAttributes: List<AllAtterPiece1>?,
        @SerializedName("s1") val atterNeedModels1: ArrayList<AtterNeedModels1>?,
        var ischoose:Boolean=false
)

data class AtterNeedModels1(
        @SerializedName("keyAttribute") val keyAttribute: String,
        @SerializedName("valueAttribute") val valueAttribute: Needs1
)

data class BrunchModel(@SerializedName("IdBrunch") val IdBrunch: Int,
                       @SerializedName("nameBrunch") val nameBrunch: String,
                       var cheacked:Boolean=false

)

data class AtterModel1(
        @SerializedName("idAttribute")val idAttributes:Int,
        @SerializedName("typeAttribute") val typeAttribute: String,
        @SerializedName("groupAttribute") val groupAttribute: String,
        @SerializedName("keyAttribute") val keyAttribute: String,
//        @SerializedName("valueAttribute") val valueAttribute: String,
        var showKeyValues: String="",
//        @SerializedName("shows")  var showKeyValues: String,
        var cheacked:Boolean=false
)



data class Needs1(
        @SerializedName("max-potential")
        val maxPotential: List<MaxPotential>,
        @SerializedName("min-need")
        val minNeed: ArrayList<MinNeed>,
        @SerializedName("need-equal")
        val needEqual: List<NeedEqual>
) {
    data class MaxPotential(
            @SerializedName("id-brunch")
            val idBrunch: Int, // 2
            @SerializedName("num")
            val num: Int // 2
    )

    data class MinNeed(
            @SerializedName("id-brunch")
            val idBrunch: Int, // 1
            @SerializedName("values")
            val values: List<Value>
    ) {
        data class Value(
                @SerializedName("Key")
                val key: String, // POWER
                @SerializedName("Value")
                val value: String // 300
        )
    }

    data class NeedEqual(
            @SerializedName("id-brunch")
            val idBrunch: Int, // 1
            @SerializedName("id-piece")
            val idPiece: Int // 100
    )
}


//data class AllAtterPiece1(
//        var listAtter1:List<AtterPiece12>
//){
//    data class  AtterPiece12(
//            @SerializedName("keyAttribute")
//            val keyAttribute: String, // POWER
//            @SerializedName("valueAttribute")
//            val valueAttribute: ValueAttribute
//    ) {
//        data class ValueAttribute(
//                @SerializedName("valueAttribute")
//                val valueAttribute: Double // 20.5
//        )
//    }
//}

data class AllAtterPiece1(
        @SerializedName("keyAttribute")
        val keyAttribute: String, // POWER
        @SerializedName("valueAttribute")
        val valueAttribute: ValueAttribute
) {
    data class ValueAttribute(
            @SerializedName("valueAttribute")
            val valueAttribute: String // 20.5
    )
}