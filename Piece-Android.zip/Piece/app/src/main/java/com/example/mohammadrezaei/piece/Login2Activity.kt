package com.example.mohammadrezaei.piece

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.design.widget.TextInputEditText
import com.example.mohammadrezaei.piece.Internets12.MySingleton
import kotlinx.android.synthetic.main.activity_login2.*
import org.json.JSONObject
//import javax.swing.UIManager.put
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.example.mohammadrezaei.piece.Internets12.StaticForAll
//import com.squareup.okhttp.*
import java.io.IOException
import java.lang.Exception
import com.android.volley.VolleyError
import org.json.JSONArray


class Login2Activity : AppCompatActivity() {
    private lateinit var user:TextInputEditText
    private lateinit var phoneNumber:TextInputEditText
    private lateinit var password:TextInputEditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login2)
        user=userNameTexts1 as TextInputEditText
        phoneNumber=phoneNum as TextInputEditText
        password=passwordText as TextInputEditText
        addListners()
    }

    fun addListners(){
        val url1=StaticForAll.URL
//    Toast.makeText(this,url,Toast.LENGTH_LONG).show()

//        val sa1:String="select addCustomer('" +
//                "mazx" +
//                "','"+"ahoooooo"+
//                "','" +"05s5a55s55s56555" +
//                "')"
//
//        LoginPost().execute(url1,sa1)
        enterProgram.setOnClickListener {
//            val queue = MySingleton.getInstance(this.applicationContext).requestQueue
            val url=StaticForAll.URL
//            Toast.makeText(this,url,Toast.LENGTH_LONG).show()
           val sa:String="select addCustomer('" +
                   user.text.toString() +
                   "','"+password.text.toString()+
                   "','" +phoneNumber.text.toString() +
                   "') as crea"

//            val  params1:HashMap<String, String> =HashMap()
//            params1.put("email", "wwww.ffff")
//            params1.put("password", "erqwrw")
//            params1.put("we", "re")
//            params1.put("type", "select")
//            params1.put("select", sa)
//            val jo:JSONObject=JSONObject(params1)
//           val  jsonObjectRequest:JsonObjectRequest= JsonObjectRequest(Request.Method.POST,url,jo,object: Response.Listener<JsonObjectRequest>{
//               override fun onResponse(response: JsonObjectRequest?) {
//
//               }
//           })

            val jsonObjectRequest1 = JsonObjectRequest(Request.Method.POST, url, StaticForAll.getPostModel(sa),
                    Response.Listener { response ->
//                        StaticForAll.toastMyMessage(this,"res"+response.toString())
//                        Toast.makeText(this,"res"+response.toString(),Toast.LENGTH_LONG).show()
                        try {
                            val ob=JSONObject(response.toString())
                            val ob1=JSONArray(ob.getString("data"))
                            val ob2=JSONObject(ob1[0].toString())
//                            Toast.makeText(this,ob2.getString("crea"),Toast.LENGTH_LONG).show()
                            when(ob2.getString("crea")){
                                "0"->{
                                    Toast.makeText(this,"ناموفق-تلفن همراه موجود است",Toast.LENGTH_LONG).show()
                                }
                                "1"->{
                                    Toast.makeText(this,"ناموفق نام کاربری موجود می باشد.",Toast.LENGTH_LONG).show()
                                }
                                "2"->{
//                                    writtingToFile()
                                    goToDashbord()
//                                    var intent:Intent= Intent(this,Dasbord2Activity::class.java)
//                intent.putExtra("password",password.text.toString())
//                intent.putExtra("userName",userNameText.text.toString())
//                intent.putExtra("phoneNum",phoneNumber.text.toString())
//                startActivity(intent)
//                writtingToFile()
//                finish()
                                    Toast.makeText(this,"اطلاعات با موفقیت ثبت گردید.",Toast.LENGTH_LONG).show()
                                }
                                "3"->{
                                    goToDashbord()
//                                    writtingToFile()
                                    Toast.makeText(this,"اطلاعات درست وارد شده است",Toast.LENGTH_LONG).show()
                                }
                                else->{
                                    Toast.makeText(this,"2-خطا در برقراری ارتباط",Toast.LENGTH_LONG).show()
                                }
                            }
                        }catch (ex:Exception){}
                       }, Response.ErrorListener {
//                throw it
//                Toast.makeText(this,"1-خطا در برقراری ارتباط",Toast.LENGTH_LONG).show()
                StaticForAll.toastError(this)
            })

//            jsonObjectRequest1.setTag(REQ_TAG);
            MySingleton.getInstance(this).requestQueue.add(jsonObjectRequest1);
//            val body:RequestBody= RequestBody.create(StaticForAll.JSON,jo.toString())
//            val request:Request=Request.Builder()
//                    .url(url)
//                    .post(body)
//                    .build()
//
//            StaticForAll.CLIENT.newCall(request).enqueue(object : Callback {
//                override fun onFailure(request: Request?, e: IOException?) {
//                    Toast.makeText(this@Login2Activity,""+e.toString(),Toast.LENGTH_LONG).show()
//                }
//
//                override fun onResponse(response: Response?) {
//                    Toast.makeText(this@Login2Activity,""+response!!.body().toString(),Toast.LENGTH_LONG).show()
//                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
//                }
//
////                fun onFailure(call: Call, e: IOException) {
////                    e.printStackTrace()
////                }
////
////                @Throws(IOException::class)
////                fun onResponse(call: Call, response: Response) {
////                    response.body().use { responseBody ->
////                        if (!response.isSuccessful) throw IOException("Unexpected code $response")
////
////                        val responseHeaders = response.headers()
////                        var i = 0
////                        val size = responseHeaders.size()
////                        while (i < size) {
////                            println(responseHeaders.name(i) + ": " + responseHeaders.value(i))
////                            i++
////                        }
////
////                        System.out.println(responseBody.string())
////                    }
////                }
//            })
//            Toast.makeText(this,sa,Toast.LENGTH_LONG).show()
////            Handler().post(Runnable {
////                LoginPost().execute(url,sa)
////            })
//            runOnUiThread {
//                LoginPost().execute(url,sa)
//                 }

//            var  params:HashMap<String, String> =HashMap()
//            params.put("email", "wwww.ffff")
//            params.put("password", "erqwrw")
//            params.put("we", "re")
//            params.put("type", "select")
//            params.put("select", sa)
//
//
//            val parameters = JSONObject(params)

//            val jsonRequest = JsonObjectRequest(Request.Method.GET, url, parameters, Response.Listener {
//                //TODO: handle success
//                Toast.makeText(this,it.toString()+"  " +
//                        ""+resources,Toast.LENGTH_LONG).show()
//            }, Response.ErrorListener { error ->
//                Toast.makeText(this,error.toString(),Toast.LENGTH_LONG).show()
//                //TODO: handle failure
//            })

//                queue.add(jsonRequest)
// Access the RequestQueue through your singleton class.
//            MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest)

//            if(user.text.toString().length>0&&phoneNumber.text.toString().length>0
//            &&password.text.toString().length>0){
//                var intent:Intent= Intent(this,Dasbord2Activity::class.java)
//                intent.putExtra("password",password.text.toString())
//                intent.putExtra("userName",userNameText.text.toString())
//                intent.putExtra("phoneNum",phoneNumber.text.toString())
//                startActivity(intent)
//                writtingToFile()
//                finish()
//            }
        }
    }

    private fun goToDashbord() {
        var intent:Intent= Intent(this,Dasbord2Activity::class.java)
                intent.putExtra("password",password.text.toString())
                intent.putExtra("userName",user.text.toString())
                intent.putExtra("phoneNum",phoneNumber.text.toString())
                startActivity(intent)
                writtingToFile()
                finish()
    }

    fun writtingToFile(){
        val sharred:SharedPreferences=applicationContext.getSharedPreferences("picesApplications", Context.MODE_PRIVATE)
        var editor:SharedPreferences.Editor=sharred.edit()
        editor.putString("password",password.text.toString())
        editor.putString("userName",user.text.toString())
        editor.putString("phoneNum",phoneNumber.text.toString())
        editor.apply()

    }

//   inner private class LoginPost:AsyncTask<String,String,String>{
//
//        constructor():super(){
//        }
//        override fun doInBackground(vararg params: String?): String {
//        val url=params[0]
//            val select=params[1]
//            val  params1:HashMap<String, String> =HashMap()
//            params1.put("email", "wwww.ffff")
//            params1.put("password", "erqwrw")
//            params1.put("we", "re")
//            params1.put("type", "select")
//            params1.put("select", select!!)
//            val jo:JSONObject=JSONObject(params1)
//            val body:RequestBody= RequestBody.create(StaticForAll.JSON,jo.toString())
//            val request:Request=Request.Builder()
//                    .url(url)
//                    .post(body)
//                    .build()
////            Toast.makeText(this@Login2Activity,"succ"+request.body().toString(),Toast.LENGTH_LONG).show()
//            try {
//                var okHttpClient=OkHttpClient()
//                var response=okHttpClient!!.newCall(request).execute()
//                if(response.isSuccessful){
//                    Toast.makeText(this@Login2Activity,"succ",Toast.LENGTH_LONG).show()
//                    return response.body().string()
//                }else{
//                    Toast.makeText(this@Login2Activity,"unsuccsucc",Toast.LENGTH_LONG).show()
//                    return ""
//                }
//            }catch (ex:Exception){
//                return ex.toString()
//            }
//        }
//
//        override fun onPostExecute(result: String?) {
//
//            Toast.makeText(this@Login2Activity,"result :"+result,Toast.LENGTH_LONG).show()
//
////                val intent = Intent(context, Dasbord2Activity::class.java)
//                val intent:Intent= Intent(this@Login2Activity,Dasbord2Activity::class.java)
//                intent.putExtra("password",password.text.toString())
//                intent.putExtra("userName",user.text.toString())
//                intent.putExtra("phoneNum",phoneNumber.text.toString())
//            startActivity(intent)
//                writtingToFile()
//            finish()
//        }
//    }

//   private class SendToServer:AsyncTask<String,String,String>(){
//       override fun doInBackground(vararg params: String?): String {
//           val url:String=params[0]!!
//           val body:String=
//       }
//
//   }


}
