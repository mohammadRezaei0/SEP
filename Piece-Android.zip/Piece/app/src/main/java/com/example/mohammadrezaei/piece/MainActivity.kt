package com.example.mohammadrezaei.piece

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        ff.setOnClickListener {
//            startActivity(Intent(this,LoginActivity::class.java))
//        }
        val shared: SharedPreferences = applicationContext.getSharedPreferences("picesApplications", Context.MODE_PRIVATE)
        val name = shared.getString("userName", "")
        val phone = shared.getString("phoneNum", "")
        val pass = shared.getString("password", "")

        if (name.length > 0 && phone.length > 0
                && pass.length > 0) {
            var intent: Intent = Intent(this, Dasbord2Activity::class.java)
            intent.putExtra("password", pass)
            intent.putExtra("userName", name)
            intent.putExtra("phoneNum", phone)
            startActivity(intent)
            finish()
        }else{

            startActivity(Intent(this,Login2Activity::class.java))
            finish()
        }
    }

}
