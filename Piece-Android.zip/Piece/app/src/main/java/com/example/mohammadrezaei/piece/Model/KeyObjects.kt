package com.example.mohammadrezaei.piece.Model

object KeyObjects {
    val pieceSelectKey:String="pieceSelects"
    val keyResult:Int=50
    val choosenItem:String="choosenItems"
}