package com.example.mohammadrezaei.piece.Internets12

import android.content.Context
import android.widget.Toast
import com.squareup.okhttp.MediaType
import com.squareup.okhttp.OkHttpClient
import org.json.JSONObject

class StaticForAll {

    companion object {
        val JSON: MediaType by lazy {
            MediaType.parse("application/json; charset=utf-8")
        }
        val CLIENT:OkHttpClient by lazy {
            OkHttpClient()
        }
        val URL: String by lazy {
            "https://m1202.herokuapp.com/eee"
        }
        fun getPostModel(select:String):JSONObject{
            val  params1:HashMap<String, String> =HashMap()
            params1.put("email", "wwww.ffff")
            params1.put("password", "erqwrw")
            params1.put("we", "re")
            params1.put("type", "select")
            params1.put("select", select)
            val jo: JSONObject = JSONObject(params1)
            return jo
        }
        fun toastError(context: Context){
            Toast.makeText(context,"1-خطا در برقراری ارتباط", Toast.LENGTH_LONG).show()
        }
        fun toastMyMessage(context: Context,string: String){
            Toast.makeText(context,string, Toast.LENGTH_LONG).show()
        }

    }


}