package com.example.mohammadrezaei.piece

import android.animation.ObjectAnimator
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.example.mohammadrezaei.piece.Model.KeyObjects
import com.example.mohammadrezaei.piece.Model.ListPeice
import com.example.mohammadrezaei.piece.Model.PieceModel
import com.google.gson.Gson
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_basket_shop2.*
import java.lang.Exception
import java.util.*

class BasketShop2Activity : AppCompatActivity() {

    private lateinit var socket:Socket

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_basket_shop2)
        val a=intent.getStringExtra(KeyObjects.choosenItem)
       val listPeice=try {
           Gson().fromJson<ListPeice>(a,ListPeice::class.java)
       }catch (ex:Exception){
           ListPeice(ArrayList<PieceModel>())
       }
        var totalPrice:Long=0;
        listPeice.listPiece.forEach {
            totalPrice+=it.price
        }
        basketPrice.text=totalPrice.toString()
        basketLists.adapter=BasketAdapter1(listPeice.listPiece)
        addBackgroundAnimation()
    }
    private fun addBackgroundAnimation() {
        var test = true
        var counter = 0
        val displayMetrics = DisplayMetrics()
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        var hiegh = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels
//        var a = arrayOf(R.drawable.ic_exposure_zero_white_24dp, R.drawable.ic_looks_one_white_24dp)
        var a = arrayOf(R.drawable.ic_attach_money_withe_24dp, R.drawable.ic_attach_money_withe_24dp)
//        var a = arrayOf(R.drawable.ic_000, R.drawable.ic_111)
        var listAnimation = ArrayList<ObjectAnimator>()
        while (test) {
            var b = true
//            var wConter=0
            var tCounters = 0
            val duration:Long=10000
            var startDelay = Random().nextInt(10000).toLong()
            while (b) {
                val i = ImageView(this)
                val params1 = RelativeLayout.LayoutParams(50, 50)
//            params1.leftMargin = wConter
                params1.leftMargin = -50
                params1.topMargin = counter
                var po = ((Random().nextInt()) % 2)
                if (po < 0)
                    po *= -1
                i.setImageDrawable(resources.getDrawable(a[po]))
                animationRelativeLayoutBasket.addView(i, params1)
                val trans: ObjectAnimator =
                        ObjectAnimator.ofFloat(i, "translationX", 0f, (width+50).toFloat())
                trans.repeatCount = ObjectAnimator.INFINITE
                trans.startDelay = startDelay
                trans.startDelay = startDelay + tCounters
                trans.duration = duration
                listAnimation.add(trans)
//                wConter-=75
//                b=(wConter*-1)<width
                tCounters += 500
                b= tCounters<duration
            }
//            trans.start()
            counter += 75
            test = counter < hiegh
        }
        listAnimation.forEach {
            it.start()
        }
//       var h= Handler()
//        var r=object :Runnable{
//            override fun run() {
//                listAnimation.forEach {
//                    it.startDelay= Random().nextInt(10000).toLong()
//                }
//                h.post(this)
//            }
//
//        }
//        h.post(r)
//        Runnable {
//            listAnimation.forEach {
//                it.startDelay= Random().nextInt(10000).toLong()
//            }
//            h.post(it)
//        }
//        h.post(r)
    }

    private inner class BasketAdapter1: BaseAdapter {
        var model:ArrayList<PieceModel>
        constructor(model: ArrayList<PieceModel>):super(){
            this.model=model
        }
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
           if(convertView==null){
               val v=layoutInflater.inflate(R.layout.row_backets,parent,false)
               if(position!=0){
                   var p=model[position-1]
                   val name=v.findViewById<TextView>(R.id.namePriceInBasket)
                   name.text=p.namePiece
                   val price=v.findViewById<TextView>(R.id.priceInBasket)
                   price.text=p.price.toString()
                   val choos=v.findViewById<TextView>(R.id.deletOrChooseBasket)
                   var c=0
                   choos.setBackgroundColor(resources.getColor(R.color.green_12))
                   choos.setOnClickListener {
                       if(c==0){
                           c++
                           choos.setBackgroundColor(resources.getColor(R.color.red_1))
                       }else{
                           c--
                           choos.setBackgroundColor(resources.getColor(R.color.green_12))
                       }
                   }
               }
               return v
           }else return convertView
        }

        override fun getItem(position: Int): Any =""

        override fun getItemId(position: Int): Long =0

        override fun getCount(): Int = model.size+1
    }







//        try {
//            socket=IO.socket("https://m1202.herokuapp.com/so")
//            socket.connect()
//        }catch (ex:Exception){
//            Toast.makeText(this,"errror "+ex.message,Toast.LENGTH_LONG).show()
//        }
//        purching.setOnClickListener(View.OnClickListener {
//            sends1()
//        })
//
//    }
//    private fun sends1(){
//        val sa1:String="select addCustomer('" +
//                "mazx" +
//                "','"+"ahoooooo"+
//                "','" +"05s5a55s55s56555" +
//                "')"
//        val  params1:HashMap<String, String> =HashMap()
//        params1.put("email", "wwww.ffff")
//        params1.put("password", "erqwrw")
//        params1.put("we", "re")
//        params1.put("type", "select")
//        params1.put("select", sa1)
//        val jo: JSONObject = JSONObject(params1)
//        socket.emit("querys",jo.toString())
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        socket.disconnect()
//    }
}
