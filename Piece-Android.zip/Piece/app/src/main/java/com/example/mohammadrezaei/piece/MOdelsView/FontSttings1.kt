package com.example.mohammadrezaei.piece.MOdelsView

import android.app.Application

class FontSttings1: Application() {
    override fun onCreate() {
        super.onCreate()
        TypefaceUtil.overrideFont(getApplicationContext(),"SERIF","Fonts/Helal.ttf");
    }
}