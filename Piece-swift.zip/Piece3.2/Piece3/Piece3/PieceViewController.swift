//
//  PieceViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/16/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import Alamofire
import ColorToast
import SwiftyJSON
import ProgressHUD



class PieceViewController: UIViewController,UITableViewDelegate,UITableViewDataSource ,SenderToPiece {
    @IBOutlet weak var pieceTable: UITableView!
    @IBOutlet weak var searchField: UITextField!
    @IBOutlet weak var goToFileter: UIButton!
    
    var listModel:[ModelPiece]=[ModelPiece]()
    var listModelAll:[ModelPiece]=[ModelPiece]()
    var selectPieceString:String="SELECT Distinct(\"Piece\".\"idPiece\"), \"Piece\".\"idBrunch\", \"namePiece\", price, \"imageSrcs\""
    + ",(select (select array_to_json(array_agg(row_to_json(t)))"
    + "from ("
    + "select \"keyAttribute\", \"valueAttribute\" from public.\"Attribute\" where \"Piece\".\"idPiece\"="+"\"Attribute\".\"idPiece\""
    + "and \"keyAttribute\"<>'need'"
    + ") t)::jsonb as s)"
    + "FROM public.\"Piece\",\"Attribute\" where \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\"";
    
    var whereSelect:String=""
    
//    let selectPieceString: String = """
//    SELECT Distinct("Piece"."idPiece"), "Piece"."idBrunch", "namePiece", price, "imageSrcs"
//    ,(select (select array_to_json(array_agg(row_to_json(t)))
//    from (
//    select "keyAttribute", "valueAttribute" from public."Attribute" where "Piece"."idPiece"="Attribute"."idPiece"
//    and "keyAttribute"<>'need'
//    ) t)::jsonb as s)
//    FROM public."Piece","Attribute" where "Piece"."idPiece"="Attribute"."idPiece"
//    """
    override func viewDidLoad() {
        super.viewDidLoad()
        setModels()
        pieceTable.delegate=self
        pieceTable.dataSource=self
        pieceTable.register(UINib(nibName:"PieceViewCell",bundle:nil), forCellReuseIdentifier: "mycell")
        pieceTable.separatorStyle = .none
        searchField.addTarget(self, action: #selector(searcher), for: .editingChanged)
        goToFileter.addTarget(self, action: #selector(goFilter), for: .touchUpInside)
        
        sizing()
    }
    func goFilter(bu:UIButton){
        performSegue(withIdentifier: "goToFilter", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToFilter" {
            let filterView=segue.destination as! FilterViewController
            filterView.senders=self
        }else if segue.identifier == "gotoBasket"{
        let filterView = segue.destination as! BascketViewController
            filterView.arrayPieces=listModel.filter{ (mo) -> Bool in
                return mo.isSelect
            }
        }
    }
    func sendToPiece(whereSelect: String) {
        self.whereSelect=whereSelect
        setModels()
    }
    
    @IBAction func sendtoBasket(_ sender: UIButton) {
        performSegue(withIdentifier: "gotoBasket", sender: self)
        
        }
    @IBOutlet weak var goToBaskets: UIButton!
    
    func searcher(field:UITextField){
        listModel.removeAll()
       listModelAll.forEach { (mo) in
        if (field.text?.lowercased().contains(mo.name.lowercased()))!{
            listModel.append(mo)
        }
        }
        pieceTable.reloadData()
    }
    func sizing(){
        pieceTable.rowHeight = UITableViewAutomaticDimension
        pieceTable.estimatedRowHeight = 300
        
    }
    
   
    
    func setModels(){
        print("selectp \(selectPieceString+whereSelect)")
        ProgressHUD.show()
        Alamofire.request(urlWeb, method: .post, parameters:createDicPost(val: selectPieceString+whereSelect)).responseJSON { (
            response) in
            if(response.result.isSuccess){
                self.listModel.removeAll()
                self.listModelAll.removeAll()
                print("respsss\(response.result.value!)")
//                do{
                let data:JSON=JSON(response.result.value)
               let data1:[JSON]? = data["data"].array
                    if data1 != nil {
                        for i in data1! {
//                            let name=i["namePiece"].string
                            let model = ModelPiece(name: i["namePiece"].string!,
                                                       imageSrc: i["imageSrcs"].string!
                                , idBrunch: i["idBrunch"].int!, idPiece: i["idPiece"].int!,
                                  price: i["price"].string!)
                            self.listModel.append(model)
                            self.listModelAll.append(model)
                        }
                    }
//                }catch{
//                    print(error)
//                }
                self.pieceTable.reloadData()
            }else{
                print("er\(response.error)")
            }
            ProgressHUD.dismiss()
        }
            
    
//        listModel.append("ss")
//        listModel.append("sas")
//        listModel.append("swr")
//        listModel.append("s1s")
//        listModel.append("s2s")
//        listModel.append("sw4r")
//        listModel.append("ss5")
//        listModel.append("esas")
//        listModel.append("swgr")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mycell", for: indexPath) as! PieceViewCell
        cell.selectionStyle = .none
//        
//        if cell.nameP != nil{
//            cell.nameP.text = listModel[indexPath.row].name
//        }
        let model = listModel[indexPath.row]
        cell.setModel(model:model)
        changer(model: model,cell:cell)
        cell.chooseB.tag = indexPath.row
        cell.chooseB.addTarget(self, action: #selector(enterBa), for: .touchUpInside)
//        imageLoader.obtainImageWithPath(imagePath: model.imageSrc) { (image) in
//            // Before assigning the image, check whether the current cell is visible
//            if let updateCell = tableView.cellForRow(at: indexPath) {
//                updateCell.imageView.image = image
//            }
//        }
        let url = URL(string: model.imageSrc)
        
        var task: URLSessionTask? = nil
        if let url = url {
            task = URLSession.shared.dataTask(with: url, completionHandler: { data, response, error in
                if data != nil {
                    var image: UIImage? = nil
                    if let data = data {
                        image = UIImage(data: data)
                    }
                    if image != nil {
                        DispatchQueue.main.async(execute: {
                            let updateCell = tableView.cellForRow(at: indexPath) as? PieceViewCell
                            if updateCell != nil {
                                updateCell?.pieceImage.image = image
                            }
                        })
                    }
                }
            })
        }
        task?.resume()

        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell=pieceTable.cellForRow(at: indexPath) as! PieceViewCell
        changer(model: listModel[indexPath.row], cell: cell, isAction: true)
        
    }
    
    func enterBa(_ sender: UIButton) {
        let p = IndexPath(row: sender.tag, section: 0)
        let cell = pieceTable.cellForRow(at: p) as! PieceViewCell
        let model=listModel[sender.tag]
        changer(model: model, cell: cell,isAction: true)
        print("yes")
    }
    func changer(model:ModelPiece,cell:PieceViewCell,isAction:Bool=false){
        
        if isAction {
            model.isSelect = !model.isSelect
        }
        
        if model.isSelect {
            cell.backgroundColor = colorSelected
        }else{
            cell.backgroundColor = colorUnselected
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
