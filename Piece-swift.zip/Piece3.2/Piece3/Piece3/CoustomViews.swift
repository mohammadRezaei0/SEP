//
//  CoustomViews.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

extension UIStackView {
    
    func addBackground(color: UIColor) {
        let subview = UIView(frame: bounds)
        subview.backgroundColor = color
        subview.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        insertSubview(subview, at: 0)
    }
    
}


extension UIImageView {
    //        public func imageFromUrl(urlString: String) {
    //            if let url = NSURL(string: urlString) {
    //                let request = NSURLRequest(URL: url)
    //                NSURLConnection.sendAsynchronousRequest(request, queue: NSOperationQueue.mainQueue()) {
    //                    (response: NSURLResponse!, data: NSData!, error: NSError!) -> Void in
    //                    self.image = UIImage(data: data)
    //                }
    //            }
    //        }
    
    //    public func imageFromUrlAlamo(url:String){
    //        Alamofire.req
    //        Alamofire.request(url,.get).response { (request, response, data, error) in
    //            self.image = UIImage(data: data, scale:1)
    //        }
    func downloaded(from url: URL, contentMode mode: UIViewContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    
    func downloaded(link: String,mode: UIViewContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
    
}


//extension UIView {
//    }
//class CheckBox: UIButton {
//    // Images
//    let checkedImage = UIImage(named: "ic_check_box")! as UIImage
//    let uncheckedImage = UIImage(named: "ic_check_box_outline_blank")! as UIImage
//    
//    // Bool property
//    var isChecked: Bool = false {
//        didSet{
//            if isChecked == true {
//                self.setImage(checkedImage, for: UIControlState.normal)
//            } else {
//                self.setImage(uncheckedImage, for: UIControlState.normal)
//            }
//        }
//    }
//    
//    override func awakeFromNib() {
//        self.addTarget(self, action:#selector(buttonClicked(sender:)), for: UIControlEvents.touchUpInside)
//        self.isChecked = false
//    }
//    
//    func buttonClicked(sender: UIButton) {
//        if sender == self {
//            isChecked = !isChecked
//        }
//    }
//}
//
//
//
//
//class RadioButton1: UIButton {
//    var alternateButton:Array<RadioButton1>?
//    
//    override func awakeFromNib() {
//        self.layer.cornerRadius = 5
//        self.layer.borderWidth = 2.0
//        self.layer.masksToBounds = true
//    }
//    
//    func unselectAlternateButtons(){
//        if alternateButton != nil {
//            self.isSelected = true
//            
//            for aButton:RadioButton1 in alternateButton! {
//                aButton.isSelected = false
//            }
//        }else{
//            toggleButton()
//        }
//    }
//    
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        unselectAlternateButtons()
//        super.touchesBegan(touches, with: event)
//    }
//    
//    func toggleButton(){
//        self.isSelected = !isSelected
//    }
//    
//    override var isSelected: Bool {
//        didSet {
//            if isSelected {
//                self.layer.borderColor = Color.turquoise.cgColor
//            } else {
//                self.layer.borderColor = Color.grey_99.cgColor
//            }
//        }
//    }
//}
