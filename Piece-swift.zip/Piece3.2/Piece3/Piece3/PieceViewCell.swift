//
//  PieceViewCell.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/16/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class PieceViewCell: UITableViewCell {
    @IBOutlet weak var pieceImage: UIImageView!
    @IBOutlet weak var nameP: UILabel!
    @IBOutlet weak var priceP: UILabel!
    @IBOutlet weak var chooseB: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setModel(model:ModelPiece){
        if nameP != nil{
            nameP.text = model.name
        }
        if priceP != nil {
            priceP.text = model.price
        }
        if pieceImage != nil {
            pieceImage.downloaded(link: model.price)
        }
        
    }
    
    @IBAction func enterB(_ sender: UIButton) {
    }
}
