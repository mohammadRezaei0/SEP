//
//  BrunchTableView.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import DLRadioButton
import Alamofire
import SwiftyJSON
import ProgressHUD

protocol SelctedButtonRe {
    func buttonTags(idBrunch:Int)
}

class BrunchTableView: UITableView,UITableViewDataSource,UITableViewDelegate {

    var radioButton:[DLRadioButton]=[DLRadioButton]()
    var r=DLRadioButton()
//    var selct:
    var selBu:SelctedButtonRe? = nil
    private let selectBrunch:String = "SELECT \"IdBrunch\", \"nameBrunch\""
        + "FROM public.\"Brunch\";"
    private var brunchArrays:[BrunchModel]=[BrunchModel]()
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.isHidden = true
        self.dataSource=self
        self.delegate=self
        self.allowsSelection = false
        self.register(UINib(nibName:"BrunchViewCell",bundle:nil), forCellReuseIdentifier: "mycellB")
        r.isHidden = true
        r.isSelected = false
        self.separatorStyle = .none
    }
    
    func getBrunch(){
        brunchArrays.append(BrunchModel(idBrunch: -1, nameBrunch: "همه"))
        ProgressHUD.show()
        Alamofire.request(urlWeb, method: .post, parameters: createDicPost(val: selectBrunch)).responseJSON { (response) in
            if(response.result.isSuccess){
                print("responseVal : \(response.result.value)")
                let data=JSON(response.result.value)
                let data1:[JSON]=data["data"].array!
                for o in data1{
                    let m=BrunchModel(idBrunch: o["IdBrunch"].int!, nameBrunch: o["nameBrunch"].string!)
                    self.brunchArrays.append(m)
                }
                for u in self.brunchArrays{
                    print(u.nameBrunch)
                }
                
            }else{
                print("sssss")
            }
            self.reloadData()
            UIView.animate(withDuration: 1){
                self.isHidden = false
            }
            ProgressHUD.dismiss()
        }
    }

    func returnSelected()->Int{
        return brunchArrays[(r.selected()?.tag)!].idBrunch
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (brunchArrays.count+1)/2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "mycellB", for: indexPath) as! BrunchViewCell
//        cell.leftRB.setTitle("left", for: .normal)
        let startpoint = indexPath.row * 2
        cell.rightRB.tag=startpoint
        cell.leftRB.tag=startpoint+1
        r.otherButtons.append(cell.leftRB)
        r.otherButtons.append(cell.rightRB)
        cell.rightRB.setTitle(brunchArrays[startpoint].nameBrunch, for: .normal)
        if startpoint+1 == brunchArrays.count {
            cell.leftRB.isHidden = true
        }else{
            cell.leftRB.setTitle(brunchArrays[startpoint+1].nameBrunch, for: .normal)
        }
        addActionToButton(button: cell.rightRB)
        addActionToButton(button: cell.leftRB)
        return cell
    }
    
    func addActionToButton(button:UIButton) {
        button.addTarget(self, action: #selector(listners), for: .touchUpInside)
    }
    func listners(button:UIButton){
        selBu?.buttonTags(idBrunch: brunchArrays[button.tag].idBrunch)
    }
    
    func selectedButton(){
        print(r.selectedButtons()[0].tag)
    }

    
}
