//
//  AttrViewCell.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import BEMCheckBox

protocol AtterChecked {
    func checkedAtter(index:Int,checkedRB:BEMCheckBox)
//        ->String
}

class AttrViewCell: UITableViewCell {
    @IBOutlet weak var leftBEM: BEMCheckBox!
    @IBOutlet weak var rightBEM: BEMCheckBox!
    @IBOutlet weak var leftB: UIButton!
    @IBOutlet weak var rightB: UIButton!
    @IBOutlet weak var leftStack: UIStackView!
    @IBOutlet weak var rightStack: UIStackView!
    var chechedCheck:AtterChecked? = nil
    
//    @IBAction func rightAction(_ sender: BEMCheckBox) {
//        print("right")
//    }
   
    @IBAction func leftAction(_ sender: BEMCheckBox) {
        print("left")
        if sender.on {
            chechedCheck?.checkedAtter(index: sender.tag,checkedRB:sender)
        }
    }
    
    @IBAction func rightAction(_ sender: BEMCheckBox) {
        print("right")
        if sender.on {
            chechedCheck?.checkedAtter(index: sender.tag,checkedRB:sender)
        }
    }
//    @IBAction func leftAction(_ sender: BEMCheckBox) {
//        print("left")
//    }
    @IBAction func activeLeftAction(_ sender: UIButton) {
//        leftBEM.on = true
        leftBEM.setOn(!leftBEM.on, animated: true)
        leftAction(leftBEM)
    }
    @IBAction func activeRightAction(_ sender: UIButton) {
    rightBEM.setOn(!rightBEM.on, animated: true)
        rightAction(rightBEM)
    }
    
    func setLeftTag(lTag:Int){
        leftBEM.tag=lTag
        leftB.tag=lTag
    }
    func setRightTag(rTag:Int){
        rightBEM.tag=rTag
        rightB.tag=rTag
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
  
    
    
    
    
}
