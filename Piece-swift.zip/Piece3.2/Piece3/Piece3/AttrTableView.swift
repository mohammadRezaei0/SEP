//
//  AttrTableView.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import ProgressHUD
import BEMCheckBox

protocol OpenTopView {
    func topViewOpen(index:Int)
}


class AttrTableView: UITableView,UITableViewDelegate,UITableViewDataSource,AtterChecked {
    
    var attrArray:[AttrModel]=[AttrModel]()
    var openTopview:OpenTopView?=nil
    var lastChecked:BEMCheckBox?=nil

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.register(UINib(nibName:"AttrViewCell",bundle:nil), forCellReuseIdentifier: "attcell")
        self.delegate=self
        self.dataSource=self
        self.isHidden = true
        self.allowsSelection = false
        self.separatorStyle = .none
    }
    
    func getAtters(select:String){
        ProgressHUD.show()
        print(select)
        Alamofire.request(urlWeb, method: .post, parameters: createDicPost(val: select)).responseJSON { (response) in
            if(response.result.isSuccess){
                print("responseVal : \(response.result.value)")
                let data=JSON(response.result.value)
                let data1:[JSON]=data["data"].array!
                for o in data1{
                    let m=AttrModel(idAttr: o["idAttribute"].int!, valueAttr: o["keyAttribute"].string!)
                    self.attrArray.append(m)
                }
                for u in self.attrArray{
                    print(u.valueAttr)
                }
                
            }else{
                print("sssss")
            }
            
            self.reloadData()
            UIView.animate(withDuration: 1){
                self.isHidden = false
            }
            ProgressHUD.dismiss()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
       return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (attrArray.count+1)/2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "attcell", for: indexPath) as! AttrViewCell
//        cell.rightCB.setTitle("llllll", for: .normal)
//        addActionToButton(button: cell.rightCB)
        cell.chechedCheck = self
        let startPoint = indexPath.row*2
        cell.setLeftTag(lTag: startPoint)
        cell.setRightTag(rTag: startPoint+1)
        cell.leftB.setTitle(attrArray[startPoint].valueAttr + attrArray[startPoint].changerValue, for: .normal)
        if startPoint+1==attrArray.count{
            cell.rightStack.isHidden = true
        }else{
          cell.rightB.setTitle(attrArray[startPoint+1].valueAttr + attrArray[startPoint+1].changerValue, for: .normal)
        }
        return cell
    }
    
    func checkedAtter(index: Int,checkedRB:BEMCheckBox) {
        lastChecked=checkedRB
        attrArray[index].isSelect = true
        openTopview?.topViewOpen(index:index)
        print(index)
        print(attrArray[index].valueAttr)
    }
    func unCheckedLast(){
        if lastChecked != nil {
            
            lastChecked?.setOn(!(lastChecked?.on)!, animated: true)
        }else{
        print("ggggdasgwgs")
        }
    }
    
    func setChngerValues(string:String,index:Int){
        attrArray[index].changerValue = string
        self.reloadData()
    }
        
//    func addActionToButton(button:DLRadioButton) {
//        button.addTarget(self, action: #selector(listners), for: .touchUpInside)
//    }
//    func listners(button:DLRadioButton){
////        selBu?.buttonTags(tagSelected: button.tag)
//        print("yes")
//        
////        button.change
//    }

}
