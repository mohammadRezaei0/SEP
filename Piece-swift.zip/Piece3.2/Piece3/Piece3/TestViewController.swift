//
//  TestViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/17/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class TestViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        addBackgroundAnimation(vi:view)
        
        // Do any additional setup after loading the view.
    }
    
//    func setAnimation(vi:UIView){
//        
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func addBackgroundAnimation(vi:UIView){
        let counHie:Float=30
        let countWid:Float=30
        var test = true
        let hiegh = Float(vi.frame.height)
        let width = Float(vi.frame.width)
        let delayLenght = 4/(width/countWid)
//        let duration:Float = 1
        var counter:Float = 0
        while test {
            var widthTest = true
            var mulC:Float = 1
            var counterWid:Float = 0
            let rounStart = Float(arc4random()) / Float(UINT32_MAX)
            while widthTest {
                let i = UIImageView(image: #imageLiteral(resourceName: "images"))
                i.contentMode = .scaleAspectFit
                i.translatesAutoresizingMaskIntoConstraints = false
                i.heightAnchor.constraint(equalToConstant: 24).isActive = true
                i.widthAnchor.constraint(equalToConstant: 24).isActive = true
                
                //            i.frame = CGRect(x: 15, y: Int(counter), width: 24, height: 24)
                vi.addSubview(i)
                i.transform = CGAffineTransform(translationX: -24, y: CGFloat(counter))
                UIView.animate(withDuration: 3, delay: TimeInterval(mulC+rounStart), options: [.repeat], animations: {
                    i.transform = CGAffineTransform(translationX: vi.frame.width, y: CGFloat(counter))
                    //                i.frame = CGRect(x: Int(vi.frame.width), y: Int(counter), width: 24, height: 24)
                    
                    }, completion: nil)
                widthTest = counterWid < width
                counterWid += countWid
                mulC += delayLenght
            }
           
            print(counter)
            
            
            
            test = counter < hiegh
            counter += counHie
        }
    
    }
    
//    
//    
//        private func addBackgroundAnimation(vi:UIView) {
//        var test = true
//        var counter = 0
//    //    val displayMetrics = DisplayMetrics()
//    //    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//        var hiegh = Float(vi.frame.height)
//        var width = Float(vi.frame.width)
//        //        var a = arrayOf(R.drawable.ic_exposure_zero_white_24dp, R.drawable.ic_looks_one_white_24dp)
////        var a = arrayOf(R.drawable.ic_0, R.drawable.ic_11)
//        //        var a = arrayOf(R.drawable.ic_000, R.drawable.ic_111)
////        var listAnimation = ArrayList<ObjectAnimator>()
//        while (test) {
//        var b = true
//        //            var wConter=0
//        var tCounters = 0
//        let duration:Long = 10000
//        var startDelay = arc4random().advanced(by: 10)
////            arc.nextInt(10000).toLong()
//        while (b) {
////        val i = ImageView(this)
//            let i = UIImageView(image: )
//        val params1 = RelativeLayout.LayoutParams(50, 50)
//        //            params1.leftMargin = wConter
//        params1.leftMargin = -50
//        params1.topMargin = counter
//        var po = ((Random().nextInt()) % 2)
//        if (po < 0)
//        po *= -1
//        i.setImageDrawable(resources.getDrawable(a[po]))
//        animationRalativeLayout.addView(i, params1)
//        val trans: ObjectAnimator =
//        ObjectAnimator.ofFloat(i, "translationX", 0f, (width+50).toFloat())
//        trans.repeatCount = ObjectAnimator.INFINITE
//        trans.startDelay = startDelay
//        trans.startDelay = startDelay + tCounters
//        trans.duration = duration
//        listAnimation.add(trans)
//        //                wConter-=75
//        //                b=(wConter*-1)<width
//        tCounters += 500
//        b= tCounters<duration
//    }
//    //            trans.start()
//    counter += 75
//    test = counter < hiegh
//    }
//    listAnimation.forEach {
//        it.start()
//    }
//    //       var h= Handler()
//    //        var r=object :Runnable{
//    //            override fun run() {
//    //                listAnimation.forEach {
//    //                    it.startDelay= Random().nextInt(10000).toLong()
//    //                }
//    //                h.post(this)
//    //            }
//    //
//    //        }
//    //        h.post(r)
//    //        Runnable {
//    //            listAnimation.forEach {
//    //                it.startDelay= Random().nextInt(10000).toLong()
//    //            }
//    //            h.post(it)
//    //        }
//    //        h.post(r)
//    }
//
    
    
    
//    private func addBackgroundAnimation(vi:UIView) {
//    var test = true
//    var counter = 0
////    val displayMetrics = DisplayMetrics()
////    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//    var hiegh = Float(vi.frame.height)
//    var width = Float(vi.frame.width)
//    //        var a = arrayOf(R.drawable.ic_exposure_zero_white_24dp, R.drawable.ic_looks_one_white_24dp)
//    var a = arrayOf(R.drawable.ic_0, R.drawable.ic_11)
//    //        var a = arrayOf(R.drawable.ic_000, R.drawable.ic_111)
//    var listAnimation = ArrayList<ObjectAnimator>()
//    while (test) {
//    var b = true
//    //            var wConter=0
//    var tCounters = 0
//    val duration:Long=10000
//    var startDelay = Random().nextInt(10000).toLong()
//    while (b) {
//    val i = ImageView(this)
//    val params1 = RelativeLayout.LayoutParams(50, 50)
//    //            params1.leftMargin = wConter
//    params1.leftMargin = -50
//    params1.topMargin = counter
//    var po = ((Random().nextInt()) % 2)
//    if (po < 0)
//    po *= -1
//    i.setImageDrawable(resources.getDrawable(a[po]))
//    animationRalativeLayout.addView(i, params1)
//    val trans: ObjectAnimator =
//    ObjectAnimator.ofFloat(i, "translationX", 0f, (width+50).toFloat())
//    trans.repeatCount = ObjectAnimator.INFINITE
//    trans.startDelay = startDelay
//    trans.startDelay = startDelay + tCounters
//    trans.duration = duration
//    listAnimation.add(trans)
//    //                wConter-=75
//    //                b=(wConter*-1)<width
//    tCounters += 500
//    b= tCounters<duration
//}
////            trans.start()
//counter += 75
//test = counter < hiegh
//}
//listAnimation.forEach {
//    it.start()
//}
////       var h= Handler()
////        var r=object :Runnable{
////            override fun run() {
////                listAnimation.forEach {
////                    it.startDelay= Random().nextInt(10000).toLong()
////                }
////                h.post(this)
////            }
////
////        }
////        h.post(r)
////        Runnable {
////            listAnimation.forEach {
////                it.startDelay= Random().nextInt(10000).toLong()
////            }
////            h.post(it)
////        }
////        h.post(r)
//}



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
