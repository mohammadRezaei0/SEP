//
//  DashboedViewCell.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class DashboedViewCell: UICollectionViewCell {
    @IBOutlet weak var textLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
