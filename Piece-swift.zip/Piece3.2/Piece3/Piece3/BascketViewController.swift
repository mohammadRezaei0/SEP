//
//  BascketViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class BascketViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var basketTable: UITableView!
    var arrayPieces:[ModelPiece]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLinearColorToView(vi: view, startColorS: "#123", endColorS: "#433", mode: 1)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arrayPieces == nil{
            return 0
        }else{
            return (arrayPieces?.count)!
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "basketCell", for: indexPath) as! BascketCell
        cell.rightLabel.text = arrayPieces?[indexPath.row].name
        cell.midLabel.text = arrayPieces?[indexPath.row].price
        cell.leftButton.tag = indexPath.row
        cell.leftButton.setTitle("وضعیت", for: .normal)
        if (arrayPieces?[indexPath.row].isSelect)! {
        cell.leftButton.backgroundColor = colorSelected
            arrayPieces?[indexPath.row].isSelect = !(arrayPieces?[indexPath.row].isSelect)!
        }else{
        cell.leftButton.backgroundColor = colorUnselected
            arrayPieces?[indexPath.row].isSelect = !(arrayPieces?[indexPath.row].isSelect)!
        }
        cell.leftButton.addTarget(self, action: #selector(changeActions), for: .touchUpInside)
        return cell
    }
    
    func changeActions(b:UIButton){
        let indexPath=IndexPath(item: b.tag, section: 0)
        let cell = basketTable.cellForRow(at: indexPath) as! BascketCell
        if (arrayPieces?[indexPath.row].isSelect)! {
            cell.leftButton.backgroundColor = colorSelected
            arrayPieces?[indexPath.row].isSelect = !(arrayPieces?[indexPath.row].isSelect)!
        }else{
            cell.leftButton.backgroundColor = colorUnselected
            arrayPieces?[indexPath.row].isSelect = !(arrayPieces?[indexPath.row].isSelect)!
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
