//
//  FilterViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/17/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import DLRadioButton

protocol SenderToPiece {
    func sendToPiece(whereSelect:String)
}

class FilterViewController: UIViewController,SelctedButtonRe,OpenTopView {
    @IBOutlet weak var brunchTable: BrunchTableView!
    @IBOutlet weak var attrTable: AttrTableView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var inTopStackview: UIStackView!
    @IBOutlet weak var getGroupButton: DLRadioButton!
    @IBOutlet weak var valueField: UITextField!
    @IBOutlet weak var whatEqLabel: UILabel!
    var senders:SenderToPiece?
    var indexTopViewOpen:Int = -1
    var isString:Bool=false
    

    override func viewDidLoad() {
        super.viewDidLoad()
        brunchTable.getBrunch()
//        view.backgroundColor = .yellow
        setLinearColorToView(vi: view, startColorS: "#123", endColorS: "#433", mode: 1)
        brunchTable.selBu=self
        attrTable.openTopview=self
        inTopStackview.addBackground(color: .white)
        getGroupButton.isSelected = true
        valueField.addTarget(self, action: #selector(valueChange), for: .editingChanged)
        topView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissTopView)))
            
        sizing()
        // Do any additional setup after loading the view.
    }
    func dismissTopView(view:UIView){
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseIn, animations: {
                self.topView.isHidden = true
                self.attrTable.unCheckedLast()
            }, completion: nil)
       
    }
    
    func valueChange(field:UITextField){
        if field.text!.isEmpty || (Double(field.text!)) != nil {
//            getGroupButton.isSelected = true
            getGroupButton.otherButtons.forEach{
                (ra) in
                ra.isEnabled = true
                isString=false
            }
        }else{
           getGroupButton.isSelected = true
            changeLableAction(getGroupButton)
            getGroupButton.otherButtons.forEach{
                (ra) in
                ra.isEnabled = false
                isString=true
            }
        }
        
    }
        
    func sizing(){
    brunchTable.rowHeight = UITableViewAutomaticDimension
    brunchTable.estimatedRowHeight = 120
        
    }
    
    func buttonTags(idBrunch: Int) {
        let sel = "SELECT DISTINCT ON(\"keyAttribute\") \"keyAttribute\",\"idAttribute\""
        + ", \"groupAttribute\", \"typeAttribute\" "
        + "FROM public.\"Attribute\",\"Piece\" where \"Attribute\".\"idPiece\"=\"Piece\".\"idPiece\" and \"idBrunch\"=\(idBrunch)";
        attrTable.getAtters(select: sel)
//        print(tagSelected)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func filtering(_ sender: UIButton) {
//        performSegue(withIdentifier: "goToPiece", sender: self)
        senders?.sendToPiece(whereSelect: createSelect())
        
        dismiss(animated: true) { 
            print("ssssssssssssssss")
        }
        
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "goToPiece"{
//           let dis = segue.destination as! PieceViewController
//            dis.resultBack=createSelect()
////            dis.setModels()
//            print(dis.resultBack)
//        
//        }
//        dismiss(animated: true, completion: nil)
//    }
    func createSelect() -> String {
       var selectWhereString=" and "
        for e in attrTable.attrArray.filter({ (att) -> Bool in
           return att.isSelect
        }) {
            //                    val e= attrMap.get(i)
            selectWhereString += "((" + "Exists(select * from \"Attribute\" where  \"Piece\".\"idPiece\"=\"Attribute\".\"idPiece\"\n" +
            "\tand ";
            selectWhereString += "\"keyAttribute\"='" + e.valueAttr
            selectWhereString += "' and \"valueAttribute\"->'valueAttribute'"+e.changerValue;
            selectWhereString += ")) and";
        }
        
        selectWhereString += " \"idBrunch\"=\(brunchTable.returnSelected()))"
        return selectWhereString
    }
    
    @IBAction func yesButton(_ sender: UIButton) {
        topView.isHidden = true
        var opre=""
        if isString {
            opre = " ? '" + valueField.text! + "'"
        }else{
            opre=" \(convertTagToOprater(op: (getGroupButton.selected()?.tag)!)) " + valueField.text!
            print(opre)
        }
        if valueField.text!.isEmpty{
            attrTable.unCheckedLast()
        }else{
//        opre += valueField.text!
            attrTable.setChngerValues(string: opre, index: indexTopViewOpen)
        }
    }
    
    func topViewOpen(index:Int){
        indexTopViewOpen = index
        valueField.text = ""
        getGroupButton.isSelected = true
        changeLableAction(getGroupButton)
        topView.isHidden = false
    }
    
    @IBAction func changeLableAction(_ sender: DLRadioButton) {
        whatEqLabel.text = "مقدار \(sender.currentTitle!) "
    }
    
    
    func convertTagToOprater(op: Int)-> String {
        switch (op) {
        case 0 :
            return "="
        case 1 :
            return ">"
            
        case 2 :
            return "<"
            
        case 3 :
            return ">="
        case 4 :
            return "<="
        case 5 :
            return "<>"
        default :
            return "="
            
        }
    }

    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
//    }
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 5
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell=tableView.dequeueReusableCell(withIdentifier: "mycellB", for: indexPath) as! BrunchViewCell
//        
//        return cell
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
