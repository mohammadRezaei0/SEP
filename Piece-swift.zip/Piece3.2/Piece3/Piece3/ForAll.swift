//
//  ForAll.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/17/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import Alamofire
import ChameleonFramework

let urlWeb="https://m1202.herokuapp.com/eee"
let colorSelected = UIColor.yellow
let colorUnselected = UIColor.lightGray

func createDicPost(val:String)->[String:String]{
    let parm1:[String:String]=["type": "select", "select": val]
    return parm1
}


func addBackgroundAnimation(vi:UIView){
    let counHie:Float=30
    let countWid:Float=30
    var test = true
    let hiegh = Float(vi.frame.height)
    let width = Float(vi.frame.width)
    let delayLenght = 10/(width/countWid)
    //        let duration:Float = 1
    var counter:Float = 0
    while test {
        var widthTest = true
        var mulC:Float = 1
        var counterWid:Float = 0
        let rounStart = Float(arc4random()) / Float(UINT32_MAX)
        while widthTest {
            let i = UIImageView(image: #imageLiteral(resourceName: "11"))
            i.tintColor = .white
            i.alpha = CGFloat(0.5)
            i.contentMode = .scaleAspectFit
            i.translatesAutoresizingMaskIntoConstraints = false
            i.heightAnchor.constraint(equalToConstant: 24).isActive = true
            i.widthAnchor.constraint(equalToConstant: 24).isActive = true
            
            //            i.frame = CGRect(x: 15, y: Int(counter), width: 24, height: 24)
            vi.addSubview(i)
            i.transform = CGAffineTransform(translationX: -24, y: CGFloat(counter))
            UIView.animate(withDuration: 10, delay: TimeInterval(mulC+rounStart), options: [.repeat], animations: {
                i.transform = CGAffineTransform(translationX: vi.frame.width, y: CGFloat(counter))
                //                i.frame = CGRect(x: Int(vi.frame.width), y: Int(counter), width: 24, height: 24)
                
                }, completion: nil)
            widthTest = counterWid < width
            counterWid += countWid
            mulC += delayLenght
        }
        
        print(counter)
        
        
        
        test = counter < hiegh
        counter += counHie
    }
    
}

func setLinearColorToView(vi:UIView,startColorS:String,endColorS:String,mode:Int){
//    let startColor = UIColor(hexString: startColorS)
//    let endColor = UIColor(hexString: endColorS)
//    let gridintMode:UIGradientStyle
//    if mode == 0{
//        gridintMode=UIGradientStyle.leftToRight
//    }else if mode == 1{
//        gridintMode=UIGradientStyle.topToBottom
//    }else{
//        gridintMode=UIGradientStyle.radial
//    
//    }
    vi.backgroundColor = UIColor(gradientStyle: .topToBottom, withFrame: vi.frame, andColors: [UIColor(hexString: startColorS),UIColor(hexString: endColorS)])
}



typealias ImageCacheLoaderCompletionHandler = ((UIImage) -> ())

class ImageCacheLoader {
    
    var task: URLSessionDownloadTask!
    var session: URLSession!
    var cache: NSCache<NSString, UIImage>!
    
    init() {
        session = URLSession.shared
        task = URLSessionDownloadTask()
        self.cache = NSCache()
    }
    
    func obtainImageWithPath(imagePath: String, completionHandler: @escaping ImageCacheLoaderCompletionHandler) {
        if let image = self.cache.object(forKey: imagePath as NSString) {
            DispatchQueue.main.async {
                completionHandler(image)
            }
        } else {
            /* You need placeholder image in your assets,
             if you want to display a placeholder to user */
            let placeholder = #imageLiteral(resourceName: "placeholder")
            DispatchQueue.main.async {
                completionHandler(placeholder)
            }
            let url: URL! = URL(string: imagePath)
            task = session.downloadTask(with: url, completionHandler: { (location, response, error) in
                if let data = try? Data(contentsOf: url) {
                    let img: UIImage! = UIImage(data: data)
                    self.cache.setObject(img, forKey: imagePath as NSString)
                    DispatchQueue.main.async {
                        completionHandler(img)
                    }
                }
            })
            task.resume()
        }
    }
}
