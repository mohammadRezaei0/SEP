//
//  ViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/16/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import ColorToast
import ProgressHUD
import ChameleonFramework

class ViewController: UIViewController {
    @IBOutlet weak var nameF: UITextField!
    @IBOutlet weak var phoneF: UITextField!
    @IBOutlet weak var passF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        setLinearColorToView(vi: view, startColorS: "#051355", endColorS: "#443", mode: 1)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func enterCheck(_ sender: UIButton) {
        let url="https://m1202.herokuapp.com/eee"
        let sa:String="select addCustomer('" +
            nameF.text! +
            "','" + passF.text! +
            "','" + phoneF.text! +
        "') as crea";
        let parm1=["type": "select", "select": sa]
        Alamofire.request(url, method: .post, parameters: parm1).responseJSON {
            (response) in
            if response.result.isSuccess{
                let datas:JSON=JSON(response.result.value!)
                let re=datas["data"][0]["crea"].intValue
                if re == 2{
                    self.dismiss(animated: true, completion: nil)
                self.performSegue(withIdentifier: "goToDashbord", sender: self)
                }else{
                    self.dismiss(animated: true, completion: nil)
                    self.performSegue(withIdentifier: "goToDashbord", sender: self)
                }
                print("re:\(re)")
            }else{
            sender.makeToast("error")
            }
        }
        
    }

}

