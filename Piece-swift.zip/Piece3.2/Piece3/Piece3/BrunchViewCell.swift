//
//  BrunchViewCell.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/17/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import DLRadioButton

class BrunchViewCell: UITableViewCell {
    @IBOutlet weak var rightRB: DLRadioButton!
    @IBOutlet weak var leftRB: DLRadioButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
