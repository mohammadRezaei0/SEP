//
//  DashbordViewController.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit
import ChameleonFramework

class DashbordViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource , UICollectionViewDelegateFlowLayout{
    @IBOutlet weak var pagerControl: UIPageControl!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var pagerViews: UICollectionView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setLinearColorToView(vi: backView, startColorS: "#123", endColorS: "#433", mode: 1)
//        backView.backgroundColor = UIColor(gradientStyle: .topToBottom, withFrame: view.frame, andColors: [UIColor(hexString: "#123"),UIColor(hexString: "#433")])
//        let startColor = UIColor(hexString: "#123")
//        view.backgroundColor = UIColor(gradientStyle: .leftToRight, withFrame: view.frame, andColors: [UIColor.red,UIColor.green])
        addBackgroundAnimation(vi: backView)
        pagerViews.register(UINib(nibName:"DashboedViewCell",bundle:nil), forCellWithReuseIdentifier: "cells")
        pagerViews.isPagingEnabled = true
        pagerControl.numberOfPages=pagerViews.numberOfItems(inSection: 0)
//        pagerControl.addTarget(self, action: #selector(s), for: .)
        // Do any additional setup after loading the view.
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        pagerControl.currentPage = Int(pageNumber)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
//    func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
//        code
//    }
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        pagerControl.currentPage = indexPath.row
//    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cells", for: indexPath) as! DashboedViewCell
//        pagerControl.currentPage = indexPath.row
        if cell.textLabel != nil{
        cell.textLabel.text = " ssss "
        }
//        cell.backgroundColor =  indexPath.row%2==0 ? .red : .yellow
//        cell.textLabel!.text = "afsfff"
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: pagerViews.frame.width, height: pagerViews.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let index=indexPath.row
        if index == 0{
//            self.dismiss(animated: true, completion: { 
                self.performSegue(withIdentifier: "showPieces", sender: self)
//            })
//            self.dismiss(animated: true, {
//                performSegue(withIdentifier: "showPieces", sender: self)
//            })
        }else if index == 1 {
            self.dismiss(animated: true, completion: nil)
        print(1)
        }else{
        print("00")
        }
    }
//    func collectionView(_ collectionView: UICollectionView, didUpdateFocusIn context: UICollectionViewFocusUpdateContext, with coordinator: UIFocusAnimationCoordinator) {
//        code
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
