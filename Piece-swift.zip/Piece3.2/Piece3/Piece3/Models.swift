//
//  Models.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/17/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class ModelPiece {
    let name:String
    let imageSrc:String
    let idBrunch:Int
    let idPiece:Int
    let price:String
    var isSelect:Bool
    
    
    init(name:String,
    imageSrc:String,
    idBrunch:Int,
    idPiece:Int,
    price:String) {
        self.idBrunch=idBrunch
        self.idPiece=idPiece
        self.imageSrc=imageSrc
        self.name=name
        self.price=price
        self.isSelect=false
    }
    
    init(name:String,
         imageSrc:String,
         idBrunch:Int,
         idPiece:Int,
         price:String,
         isSelect:Bool) {
        self.idBrunch=idBrunch
        self.idPiece=idPiece
        self.imageSrc=imageSrc
        self.name=name
        self.price=price
        self.isSelect=isSelect
    }
    
}


class BrunchModel{
    let idBrunch:Int
    let nameBrunch:String
    init(idBrunch:Int,nameBrunch:String) {
        self.idBrunch=idBrunch
        self.nameBrunch=nameBrunch
    }
}


class AttrModel{
    let idAttr:Int
    let valueAttr:String
    var changerValue:String
    var isSelect:Bool
    init(idAttr:Int,valueAttr:String) {
        self.idAttr=idAttr
        self.valueAttr=valueAttr
        self.changerValue=valueAttr
        isSelect=false
    }
    init(idAttr:Int,valueAttr:String,changerValue:String) {
        self.idAttr=idAttr
        self.valueAttr=valueAttr
        self.changerValue=changerValue
        isSelect=false
    }
    init(idAttr:Int,valueAttr:String,changerValue:String,isSelect:Bool) {
        self.idAttr=idAttr
        self.valueAttr=valueAttr
        self.changerValue=changerValue
        self.isSelect=isSelect
    }
    
}



