//
//  TopUIView.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/19/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class TopUIView: UIControl {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    

}
