//
//  BascketCell.swift
//  Piece3
//
//  Created by Mohammad Rezaei on 1/18/19.
//  Copyright © 2019 Mohammad Rezaei. All rights reserved.
//

import UIKit

class BascketCell: UITableViewCell {
    @IBOutlet weak var rightLabel: UILabel!
    @IBOutlet weak var midLabel: UILabel!
    @IBOutlet weak var leftButton: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func changes(_ sender: UIButton) {
    }

}
